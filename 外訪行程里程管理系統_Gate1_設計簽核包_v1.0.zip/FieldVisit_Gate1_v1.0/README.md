# Gate 1 設計簽核包 v1.0

本資料包以「外訪行程里程管理系統 Prototype v2」為功能基準，目的為在正式開發前先完成 Architecture / Data / API / Permission Sign-off。

## 本階段不做
- 不建立正式 SQL Server / Azure SQL Database。
- 不建立正式 Microsoft Entra ID App Registration。
- 不產生完整 .NET 8 Solution 與 React 專案。
- 不部署正式 Google API Key。

## 本階段交付
- `docs/Architecture_Mermaid.md`：UAT / 正式候選架構、模組、ERD、狀態與批次流程。
- `database/SQL_Schema_Draft.sql`：SQL Server 2019+ Schema 草案，僅供 DBA / IT Review。
- `contracts/openapi-draft.yaml`：ASP.NET Core .NET 8+ API Contract 草案。
- `contracts/json-schema/*.json`：核心資料契約草案。
- `外訪行程里程管理系統_Gate1_資料設計工作簿_v1.0.xlsx`：Data Dictionary、權限、API、串接點、待確認事項。
- `外訪行程里程管理系統_Gate1_系統設計簽核_v1.0.docx`：跨業務與 IT 的 Gate 1 簽核文件。

## 下一個 Gate
Gate 1 簽核後，才建立 Code Skeleton：React + TypeScript + ASP.NET Core .NET 8+，以 Mock / UAT Provider 驗證契約；正式資料庫仍可延後到 Gate 3。
