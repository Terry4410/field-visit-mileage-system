# 外訪行程里程管理系統 Gate 1 架構與 ERD（設計草案）

> 狀態：Design Draft / 尚未建立正式資料庫 / 尚未建立正式 Entra ID 串接。

## 1. UAT 架構（建議基準）

```mermaid
flowchart LR
    U[外訪員 / 小組長 / 管理者 / 督導\n手機或電腦瀏覽器]
    GH[GitHub Repository\nSource + Actions]
    FE[GitHub Pages\nReact + TypeScript]
    API[Azure App Service UAT\nASP.NET Core Web API\n.NET 8+]
    DB[(Azure SQL UAT)]
    R[Google Routes API\nTWO_WHEELER]
    G[Google Geocoding API]
    LOG[Application Insights / Log]

    GH --> FE
    GH --> API
    U -->|HTTPS| FE
    FE -->|REST / JSON| API
    API --> DB
    API --> R
    API --> G
    API --> LOG
```

## 2. 正式環境候選架構

### 候選 A：DMZ API 直接連 Intranet SQL Server（需 IT / 資安核准）

```mermaid
flowchart LR
    U[使用者]
    W[DMZ Web / API\nASP.NET Core .NET 8+]
    SQL[(Intranet\nSQL Server 2019+)]
    ENTRA[Microsoft Entra ID]
    MAP[Google Maps APIs]
    U -->|HTTPS| W
    W --> ENTRA
    W -->|Firewall allow-list| SQL
    W --> MAP
```

### 候選 B：DMZ 與 Intranet 再分層

```mermaid
flowchart LR
    U[使用者]
    DMZ[DMZ Web / Edge API]
    INT[Intranet Application API]
    SQL[(SQL Server 2019+)]
    ENTRA[Microsoft Entra ID]
    MAP[Google Maps APIs]
    U -->|HTTPS| DMZ
    DMZ --> ENTRA
    DMZ -->|HTTPS allow-list| INT
    INT --> SQL
    INT --> MAP
```

> Gate 1 不決定 A 或 B；由 IT / 資安確認 DMZ 是否允許直接存取 Intranet SQL Server。

## 3. 程式模組邊界

```mermaid
flowchart TD
    UI[React UI / Pages / Components]
    APP[Application Hooks / Use Cases]
    IF[Service Interfaces / API Contracts]
    API[ASP.NET Core API]
    DOM[Domain Rules]
    INF[Infrastructure\nEF Core / SQL / Excel]
    INT[Integrations\nEntra / Google / Notification]

    UI --> APP
    APP --> IF
    IF --> API
    API --> DOM
    API --> INF
    API --> INT
```

核心原則：React Component 不直接操作 SQL、Entra ID 或 Google API；業務規則不依賴 Infrastructure。

## 4. 核心 ERD

```mermaid
erDiagram
    USERS ||--o{ USER_ROLES : has
    ROLES ||--o{ USER_ROLES : grants
    USERS ||--o{ USER_GROUP_ASSIGNMENTS : belongs
    GROUPS ||--o{ USER_GROUP_ASSIGNMENTS : contains

    GROUPS ||--o{ LOCATIONS : manages
    GROUPS ||--o{ PROJECTS : owns
    PROJECTS ||--o{ PROJECT_LOCATIONS : has
    LOCATIONS ||--o{ PROJECT_LOCATIONS : allowed

    USERS ||--o{ TRIPS : creates
    GROUPS ||--o{ TRIPS : scopes
    TRIPS ||--o{ TRIP_STOPS : contains
    LOCATIONS ||--o{ TRIP_STOPS : referenced
    PROJECTS ||--o{ TRIP_STOPS : tagged
    VISIT_TYPES ||--o{ TRIP_STOPS : tagged

    TRIPS ||--o{ TRIP_STATUS_HISTORIES : records
    TRIPS ||--o{ TRIP_APPROVALS : reviewed
    USERS ||--o{ TRIP_APPROVALS : decides

    SUBSIDY_RATES ||--o{ TRIPS : applied

    MILEAGE_CALCULATION_JOBS ||--o{ MILEAGE_CALCULATION_JOB_ITEMS : contains
    TRIPS ||--o{ MILEAGE_CALCULATION_JOB_ITEMS : calculated

    USERS ||--o{ AUDIT_LOGS : acts
```

## 5. 行程狀態

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Submitted : 外訪員送出
    Submitted --> RoutePending : 建立里程工作
    RoutePending --> RouteCalculated : Google 計算成功
    RouteCalculated --> PendingApproval
    PendingApproval --> Approved : 小組長核准
    PendingApproval --> Returned : 小組長退回
    Returned --> Submitted : 外訪員修正重送
    Draft --> Cancelled : 取消（政策待確認）
```

## 6. 批次里程流程

```mermaid
sequenceDiagram
    participant L as 小組長
    participant API as .NET API
    participant DB as SQL
    participant G as Google Routes

    L->>API: POST /api/v1/mileage-jobs\nAllPending 或 DateRange
    API->>DB: 建立 Job + Items
    API-->>L: 202 Accepted + jobId
    loop 每一筆待計算行程
        API->>DB: 讀 TripStops / 座標
        API->>G: Compute Routes (TWO_WHEELER)
        G-->>API: distance / error
        API->>DB: 更新 GoogleMileage / Item result
    end
    L->>API: GET /api/v1/mileage-jobs/{jobId}
    API-->>L: 成功 / 略過 / 失敗摘要
```

## 7. 補助費率原則

- 管理者維護 `SubsidyRates`，每筆有 `EffectiveDate`。
- 行程核准時以 `TripDate` 找到當日有效費率。
- 正式補助金額建議於核准時鎖定：`ApprovedMileage × AppliedSubsidyRate`。
- `Trips` 保存 `AppliedSubsidyRate` 與 `SubsidyAmount` 快照，避免日後新費率改寫歷史。
- 2.5 元/公里已作為 UAT 示例；正式生效日期仍需業務確認。

