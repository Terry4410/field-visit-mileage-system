/*
  外訪行程里程管理系統 - Gate 1 SQL Schema Draft v1.0
  TARGET: Microsoft SQL Server 2019+
  STATUS: DESIGN DRAFT ONLY. DO NOT EXECUTE IN PRODUCTION.
  NOTE: No database has been created by this script in Gate 1.
*/

-- Suggested schema: dbo (subject to DBA standards)

CREATE TABLE dbo.Users (
    UserId uniqueidentifier NOT NULL CONSTRAINT DF_Users_UserId DEFAULT NEWSEQUENTIALID(),
    EmployeeNo nvarchar(30) NULL,
    EntraObjectId nvarchar(100) NULL,
    DisplayName nvarchar(100) NOT NULL,
    Email nvarchar(254) NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_Users_Status DEFAULT 'Active',
    CreatedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_Users_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
    UpdatedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_Users_UpdatedAtUtc DEFAULT SYSUTCDATETIME(),
    RowVersion rowversion NOT NULL,
    CONSTRAINT PK_Users PRIMARY KEY (UserId)
);
CREATE UNIQUE INDEX UX_Users_EmployeeNo ON dbo.Users(EmployeeNo) WHERE EmployeeNo IS NOT NULL;
CREATE UNIQUE INDEX UX_Users_EntraObjectId ON dbo.Users(EntraObjectId) WHERE EntraObjectId IS NOT NULL;

CREATE TABLE dbo.Roles (
    RoleId uniqueidentifier NOT NULL CONSTRAINT DF_Roles_RoleId DEFAULT NEWSEQUENTIALID(),
    RoleCode varchar(30) NOT NULL,
    RoleName nvarchar(50) NOT NULL,
    CONSTRAINT PK_Roles PRIMARY KEY (RoleId),
    CONSTRAINT UQ_Roles_RoleCode UNIQUE (RoleCode)
);

CREATE TABLE dbo.UserRoles (
    UserId uniqueidentifier NOT NULL,
    RoleId uniqueidentifier NOT NULL,
    EffectiveFrom date NULL,
    EffectiveTo date NULL,
    CONSTRAINT PK_UserRoles PRIMARY KEY (UserId, RoleId),
    CONSTRAINT FK_UserRoles_Users FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId),
    CONSTRAINT FK_UserRoles_Roles FOREIGN KEY (RoleId) REFERENCES dbo.Roles(RoleId)
);

CREATE TABLE dbo.Groups (
    GroupId uniqueidentifier NOT NULL CONSTRAINT DF_Groups_GroupId DEFAULT NEWSEQUENTIALID(),
    GroupCode varchar(30) NOT NULL,
    GroupName nvarchar(100) NOT NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_Groups_Status DEFAULT 'Active',
    CONSTRAINT PK_Groups PRIMARY KEY (GroupId),
    CONSTRAINT UQ_Groups_GroupCode UNIQUE (GroupCode)
);

CREATE TABLE dbo.UserGroupAssignments (
    AssignmentId uniqueidentifier NOT NULL CONSTRAINT DF_UserGroupAssignments_Id DEFAULT NEWSEQUENTIALID(),
    UserId uniqueidentifier NOT NULL,
    GroupId uniqueidentifier NOT NULL,
    IsLeader bit NOT NULL CONSTRAINT DF_UserGroupAssignments_IsLeader DEFAULT 0,
    EffectiveFrom date NOT NULL,
    EffectiveTo date NULL,
    CONSTRAINT PK_UserGroupAssignments PRIMARY KEY (AssignmentId),
    CONSTRAINT FK_UserGroupAssignments_Users FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId),
    CONSTRAINT FK_UserGroupAssignments_Groups FOREIGN KEY (GroupId) REFERENCES dbo.Groups(GroupId)
);
CREATE INDEX IX_UserGroupAssignments_Group_User ON dbo.UserGroupAssignments(GroupId, UserId, EffectiveFrom, EffectiveTo);

CREATE TABLE dbo.Locations (
    LocationId uniqueidentifier NOT NULL CONSTRAINT DF_Locations_Id DEFAULT NEWSEQUENTIALID(),
    GroupId uniqueidentifier NULL,
    LocationName nvarchar(200) NOT NULL,
    City nvarchar(50) NULL,
    District nvarchar(50) NULL,
    Address nvarchar(500) NULL,
    PlusCode nvarchar(100) NULL,
    Latitude decimal(10,7) NULL,
    Longitude decimal(10,7) NULL,
    SourceType varchar(30) NOT NULL CONSTRAINT DF_Locations_SourceType DEFAULT 'Master',
    CreatedDate date NOT NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_Locations_Status DEFAULT 'Pending',
    RowVersion rowversion NOT NULL,
    CONSTRAINT PK_Locations PRIMARY KEY (LocationId),
    CONSTRAINT FK_Locations_Groups FOREIGN KEY (GroupId) REFERENCES dbo.Groups(GroupId),
    CONSTRAINT CK_Locations_AddressOrPlusCode CHECK (Address IS NOT NULL OR PlusCode IS NOT NULL)
);
CREATE INDEX IX_Locations_Group_Status_Name ON dbo.Locations(GroupId, Status, LocationName);
CREATE INDEX IX_Locations_Status_CreatedDate ON dbo.Locations(Status, CreatedDate);

CREATE TABLE dbo.Projects (
    ProjectId uniqueidentifier NOT NULL CONSTRAINT DF_Projects_Id DEFAULT NEWSEQUENTIALID(),
    ProjectName nvarchar(200) NOT NULL,
    GroupId uniqueidentifier NOT NULL,
    LocationMode varchar(30) NOT NULL,
    EffectiveDate date NULL,
    EndDate date NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_Projects_Status DEFAULT 'Active',
    CONSTRAINT PK_Projects PRIMARY KEY (ProjectId),
    CONSTRAINT FK_Projects_Groups FOREIGN KEY (GroupId) REFERENCES dbo.Groups(GroupId),
    CONSTRAINT CK_Projects_LocationMode CHECK (LocationMode IN ('List','SelfMaintained'))
);

CREATE TABLE dbo.ProjectLocations (
    ProjectId uniqueidentifier NOT NULL,
    LocationId uniqueidentifier NOT NULL,
    CONSTRAINT PK_ProjectLocations PRIMARY KEY (ProjectId, LocationId),
    CONSTRAINT FK_ProjectLocations_Projects FOREIGN KEY (ProjectId) REFERENCES dbo.Projects(ProjectId),
    CONSTRAINT FK_ProjectLocations_Locations FOREIGN KEY (LocationId) REFERENCES dbo.Locations(LocationId)
);

CREATE TABLE dbo.VisitTypes (
    VisitTypeId uniqueidentifier NOT NULL CONSTRAINT DF_VisitTypes_Id DEFAULT NEWSEQUENTIALID(),
    VisitTypeCode varchar(30) NOT NULL,
    VisitTypeName nvarchar(100) NOT NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_VisitTypes_Status DEFAULT 'Active',
    CONSTRAINT PK_VisitTypes PRIMARY KEY (VisitTypeId),
    CONSTRAINT UQ_VisitTypes_Code UNIQUE (VisitTypeCode)
);

CREATE TABLE dbo.SubsidyRates (
    SubsidyRateId uniqueidentifier NOT NULL CONSTRAINT DF_SubsidyRates_Id DEFAULT NEWSEQUENTIALID(),
    RatePerKm decimal(10,2) NOT NULL,
    EffectiveDate date NOT NULL,
    Note nvarchar(500) NULL,
    CreatedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_SubsidyRates_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
    CreatedBy uniqueidentifier NOT NULL,
    CONSTRAINT PK_SubsidyRates PRIMARY KEY (SubsidyRateId),
    CONSTRAINT UQ_SubsidyRates_EffectiveDate UNIQUE (EffectiveDate),
    CONSTRAINT CK_SubsidyRates_Rate CHECK (RatePerKm >= 0),
    CONSTRAINT FK_SubsidyRates_Users FOREIGN KEY (CreatedBy) REFERENCES dbo.Users(UserId)
);

CREATE TABLE dbo.Trips (
    TripId uniqueidentifier NOT NULL CONSTRAINT DF_Trips_Id DEFAULT NEWSEQUENTIALID(),
    TripNo varchar(30) NOT NULL,
    VisitorUserId uniqueidentifier NOT NULL,
    GroupId uniqueidentifier NOT NULL,
    TripDate date NOT NULL,
    StartTime time(0) NOT NULL,
    EndTime time(0) NOT NULL,
    HasTimeOverlapWarning bit NOT NULL CONSTRAINT DF_Trips_Overlap DEFAULT 0,
    TimeOverlapConfirmed bit NOT NULL CONSTRAINT DF_Trips_OverlapConfirm DEFAULT 0,
    SelfMileage decimal(10,2) NULL,
    GoogleMileage decimal(10,2) NULL,
    ApprovedMileage decimal(10,2) NULL,
    SubsidyRateId uniqueidentifier NULL,
    AppliedSubsidyRate decimal(10,2) NULL,
    SubsidyAmount decimal(12,2) NULL,
    Status varchar(30) NOT NULL CONSTRAINT DF_Trips_Status DEFAULT 'Draft',
    Remark nvarchar(1000) NULL,
    CreatedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_Trips_CreatedAt DEFAULT SYSUTCDATETIME(),
    CreatedBy uniqueidentifier NOT NULL,
    UpdatedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_Trips_UpdatedAt DEFAULT SYSUTCDATETIME(),
    UpdatedBy uniqueidentifier NOT NULL,
    RowVersion rowversion NOT NULL,
    CONSTRAINT PK_Trips PRIMARY KEY (TripId),
    CONSTRAINT UQ_Trips_TripNo UNIQUE (TripNo),
    CONSTRAINT FK_Trips_Visitor FOREIGN KEY (VisitorUserId) REFERENCES dbo.Users(UserId),
    CONSTRAINT FK_Trips_Groups FOREIGN KEY (GroupId) REFERENCES dbo.Groups(GroupId),
    CONSTRAINT FK_Trips_SubsidyRates FOREIGN KEY (SubsidyRateId) REFERENCES dbo.SubsidyRates(SubsidyRateId),
    CONSTRAINT CK_Trips_Time CHECK (EndTime > StartTime),
    CONSTRAINT CK_Trips_Mileage CHECK (
        (SelfMileage IS NULL OR SelfMileage >= 0) AND
        (GoogleMileage IS NULL OR GoogleMileage >= 0) AND
        (ApprovedMileage IS NULL OR ApprovedMileage >= 0)
    )
);
CREATE INDEX IX_Trips_Visitor_Date ON dbo.Trips(VisitorUserId, TripDate DESC);
CREATE INDEX IX_Trips_Group_Date_Status ON dbo.Trips(GroupId, TripDate DESC, Status);

CREATE TABLE dbo.TripStops (
    TripStopId uniqueidentifier NOT NULL CONSTRAINT DF_TripStops_Id DEFAULT NEWSEQUENTIALID(),
    TripId uniqueidentifier NOT NULL,
    SequenceNo int NOT NULL,
    LocationId uniqueidentifier NULL,
    ProjectId uniqueidentifier NULL,
    VisitTypeId uniqueidentifier NULL,
    SourceType varchar(30) NOT NULL,
    LocationNameSnapshot nvarchar(200) NOT NULL,
    AddressSnapshot nvarchar(500) NULL,
    LatitudeSnapshot decimal(10,7) NULL,
    LongitudeSnapshot decimal(10,7) NULL,
    CONSTRAINT PK_TripStops PRIMARY KEY (TripStopId),
    CONSTRAINT UQ_TripStops_Trip_Sequence UNIQUE (TripId, SequenceNo),
    CONSTRAINT FK_TripStops_Trips FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),
    CONSTRAINT FK_TripStops_Locations FOREIGN KEY (LocationId) REFERENCES dbo.Locations(LocationId),
    CONSTRAINT FK_TripStops_Projects FOREIGN KEY (ProjectId) REFERENCES dbo.Projects(ProjectId),
    CONSTRAINT FK_TripStops_VisitTypes FOREIGN KEY (VisitTypeId) REFERENCES dbo.VisitTypes(VisitTypeId)
);

CREATE TABLE dbo.TripStatusHistories (
    HistoryId uniqueidentifier NOT NULL CONSTRAINT DF_TripStatusHistories_Id DEFAULT NEWSEQUENTIALID(),
    TripId uniqueidentifier NOT NULL,
    PreviousStatus varchar(30) NULL,
    NewStatus varchar(30) NOT NULL,
    ActionType varchar(50) NOT NULL,
    ActionBy uniqueidentifier NOT NULL,
    ActionAtUtc datetime2(0) NOT NULL CONSTRAINT DF_TripStatusHistories_At DEFAULT SYSUTCDATETIME(),
    ReasonCode varchar(50) NULL,
    Comment nvarchar(1000) NULL,
    CONSTRAINT PK_TripStatusHistories PRIMARY KEY (HistoryId),
    CONSTRAINT FK_TripStatusHistories_Trips FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),
    CONSTRAINT FK_TripStatusHistories_Users FOREIGN KEY (ActionBy) REFERENCES dbo.Users(UserId)
);
CREATE INDEX IX_TripStatusHistories_Trip_Time ON dbo.TripStatusHistories(TripId, ActionAtUtc);

CREATE TABLE dbo.TripApprovals (
    ApprovalId uniqueidentifier NOT NULL CONSTRAINT DF_TripApprovals_Id DEFAULT NEWSEQUENTIALID(),
    TripId uniqueidentifier NOT NULL,
    LeaderUserId uniqueidentifier NOT NULL,
    Decision varchar(20) NOT NULL,
    ApprovedMileage decimal(10,2) NULL,
    ReasonCode varchar(50) NULL,
    Comment nvarchar(1000) NULL,
    DecisionAtUtc datetime2(0) NOT NULL CONSTRAINT DF_TripApprovals_At DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_TripApprovals PRIMARY KEY (ApprovalId),
    CONSTRAINT FK_TripApprovals_Trips FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId),
    CONSTRAINT FK_TripApprovals_Users FOREIGN KEY (LeaderUserId) REFERENCES dbo.Users(UserId),
    CONSTRAINT CK_TripApprovals_Decision CHECK (Decision IN ('Approved','Returned'))
);

CREATE TABLE dbo.MileageCalculationJobs (
    JobId uniqueidentifier NOT NULL CONSTRAINT DF_MileageJobs_Id DEFAULT NEWSEQUENTIALID(),
    Mode varchar(20) NOT NULL,
    StartDate date NULL,
    EndDate date NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_MileageJobs_Status DEFAULT 'Queued',
    RequestedBy uniqueidentifier NOT NULL,
    RequestedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_MileageJobs_Requested DEFAULT SYSUTCDATETIME(),
    CompletedAtUtc datetime2(0) NULL,
    CONSTRAINT PK_MileageCalculationJobs PRIMARY KEY (JobId),
    CONSTRAINT FK_MileageJobs_Users FOREIGN KEY (RequestedBy) REFERENCES dbo.Users(UserId),
    CONSTRAINT CK_MileageJobs_Mode CHECK (Mode IN ('AllPending','DateRange','Selected'))
);

CREATE TABLE dbo.MileageCalculationJobItems (
    JobItemId uniqueidentifier NOT NULL CONSTRAINT DF_MileageJobItems_Id DEFAULT NEWSEQUENTIALID(),
    JobId uniqueidentifier NOT NULL,
    TripId uniqueidentifier NOT NULL,
    Status varchar(20) NOT NULL CONSTRAINT DF_MileageJobItems_Status DEFAULT 'Pending',
    CalculatedMileage decimal(10,2) NULL,
    ErrorCode varchar(50) NULL,
    ErrorMessage nvarchar(1000) NULL,
    CONSTRAINT PK_MileageCalculationJobItems PRIMARY KEY (JobItemId),
    CONSTRAINT FK_MileageJobItems_Jobs FOREIGN KEY (JobId) REFERENCES dbo.MileageCalculationJobs(JobId),
    CONSTRAINT FK_MileageJobItems_Trips FOREIGN KEY (TripId) REFERENCES dbo.Trips(TripId)
);
CREATE INDEX IX_MileageJobItems_Job_Status ON dbo.MileageCalculationJobItems(JobId, Status);

CREATE TABLE dbo.ImportJobs (
    ImportJobId uniqueidentifier NOT NULL CONSTRAINT DF_ImportJobs_Id DEFAULT NEWSEQUENTIALID(),
    ImportType varchar(30) NOT NULL,
    FileName nvarchar(260) NOT NULL,
    TotalRows int NOT NULL CONSTRAINT DF_ImportJobs_Total DEFAULT 0,
    SuccessRows int NOT NULL CONSTRAINT DF_ImportJobs_Success DEFAULT 0,
    FailedRows int NOT NULL CONSTRAINT DF_ImportJobs_Failed DEFAULT 0,
    RequestedBy uniqueidentifier NOT NULL,
    RequestedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_ImportJobs_Requested DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_ImportJobs PRIMARY KEY (ImportJobId),
    CONSTRAINT FK_ImportJobs_Users FOREIGN KEY (RequestedBy) REFERENCES dbo.Users(UserId)
);

CREATE TABLE dbo.AuditLogs (
    AuditLogId bigint IDENTITY(1,1) NOT NULL,
    UserId uniqueidentifier NULL,
    ActionType varchar(50) NOT NULL,
    EntityType varchar(50) NOT NULL,
    EntityId nvarchar(100) NULL,
    Detail nvarchar(max) NULL,
    OccurredAtUtc datetime2(0) NOT NULL CONSTRAINT DF_AuditLogs_At DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_AuditLogs PRIMARY KEY (AuditLogId),
    CONSTRAINT FK_AuditLogs_Users FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);
CREATE INDEX IX_AuditLogs_OccurredAt ON dbo.AuditLogs(OccurredAtUtc DESC);
CREATE INDEX IX_AuditLogs_Entity ON dbo.AuditLogs(EntityType, EntityId, OccurredAtUtc DESC);

/* Gate 1 open decisions that can change DDL:
   1) Whether DMZ API directly connects to SQL Server or uses an Intranet API layer.
   2) Formal subsidy rate effective date.
   3) Whether locations can be shared across groups.
   4) Whether one user may hold multiple concurrent roles/groups.
   5) Company's audit-retention and data-retention requirements.
*/
