#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / "backend/src/FieldVisit.Infrastructure/WorkbookImportService.cs"
text = p.read_text(encoding="utf-8")

old = '''        foreach (var row in pendingLinks)
        {
            await StageAsync(
                batch,
                preview,
                row.RowNo,
                "ProjectLocation",
                "Upsert",
                $"{row.Data.ProjectCode.Trim()}/{row.Data.LocationCode.Trim()}",
                row.Data,
                row.Error,
                ct);
        }'''

new = '''        foreach (var row in pendingLinks)
        {
            var action = "Create";

            if (row.Error is null)
            {
                var projectCode = row.Data.ProjectCode.Trim();
                var locationCode = row.Data.LocationCode.Trim();
                var requestedActive = ParseActive(row.Data.Status);

                var project = await db.Projects
                    .AsNoTracking()
                    .FirstOrDefaultAsync(
                        x => x.OrganizationId == user.OrganizationId
                             && x.ProjectCode == projectCode,
                        ct);

                // If the Project does not exist in DB yet but was validly staged
                // in this same workbook, the relation is a true Create.
                if (project is not null)
                {
                    var location = await db.Locations
                        .AsNoTracking()
                        .FirstOrDefaultAsync(
                            x => (x.OrganizationId == user.OrganizationId
                                  || x.OrganizationId == null)
                                 && x.LocationCode == locationCode,
                            ct);

                    if (location is not null)
                    {
                        var existingLink = await db.ProjectLocations
                            .AsNoTracking()
                            .FirstOrDefaultAsync(
                                x => x.ProjectId == project.ProjectId
                                     && x.LocationId == location.LocationId,
                                ct);

                        if (existingLink is null)
                        {
                            action = "Create";
                        }
                        else if (existingLink.IsActive == requestedActive
                                 && !existingLink.IsPrimary)
                        {
                            action = "NoChange";
                        }
                        else
                        {
                            action = "Update";
                        }
                    }
                }
            }

            await StageAsync(
                batch,
                preview,
                row.RowNo,
                "ProjectLocation",
                action,
                $"{row.Data.ProjectCode.Trim()}/{row.Data.LocationCode.Trim()}",
                row.Data,
                row.Error,
                ct);
        }'''

if new in text:
    print("ProjectLocation Preview action: already patched")
elif old not in text:
    raise SystemExit("ProjectLocation Stage marker not found; stop to avoid patching wrong version")
else:
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("ProjectLocation Preview action: patched")
