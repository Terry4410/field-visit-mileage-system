#!/usr/bin/env python3
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def read(rel):
    p=ROOT/rel
    if not p.exists():
        raise SystemExit(f"找不到檔案: {rel}")
    return p.read_text(encoding="utf-8")

def write(rel,text):
    p=ROOT/rel
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding="utf-8")

def replace_once(text,old,new,label):
    if new in text:
        print(f"{label}: already patched")
        return text
    if old not in text:
        raise SystemExit(f"{label}: marker not found，停止以避免誤改。")
    return text.replace(old,new,1)

rel="backend/src/FieldVisit.Application/Contracts.cs"
s=read(rel)
s=replace_once(s,
'''    TimeOnly? StartTime,
    TimeOnly? EndTime,
    string Status,
''',
'''    TimeOnly? StartTime,
    TimeOnly? EndTime,
    bool HasTimeOverlapWarning,
    bool TimeOverlapConfirmed,
    string Status,
''',"Contracts.TripDto overlap fields")
write(rel,s)

rel="backend/src/FieldVisit.Application/TripService.cs"
s=read(rel)
s=replace_once(s,
'''            trip.StartTime,
            trip.EndTime,
            trip.Status,
''',
'''            trip.StartTime,
            trip.EndTime,
            trip.HasTimeOverlapWarning,
            trip.TimeOverlapConfirmed,
            trip.Status,
''',"TripService.MapAsync overlap fields")
write(rel,s)

rel="frontend/src/types.ts"
s=read(rel)
s=replace_once(s,
'''export interface Trip{visitTripId:number;tripNo:string;userId:number;visitorName:string;teamId?:number;teamName?:string;visitDate:string;startTime?:string;endTime?:string;status:string;statusName:string;purpose?:string;notes?:string;returnReason?:string;claimedDistanceKm?:number;systemDistanceKm?:number;approvedDistanceKm?:number;ratePerKmSnapshot?:number;approvedAmount?:number;stops:TripStopInput[];rowVersion:string}''',
'''export interface Trip{visitTripId:number;tripNo:string;userId:number;visitorName:string;teamId?:number;teamName?:string;visitDate:string;startTime?:string;endTime?:string;hasTimeOverlapWarning:boolean;timeOverlapConfirmed:boolean;status:string;statusName:string;purpose?:string;notes?:string;returnReason?:string;claimedDistanceKm?:number;systemDistanceKm?:number;approvedDistanceKm?:number;ratePerKmSnapshot?:number;approvedAmount?:number;stops:TripStopInput[];rowVersion:string}''',"frontend Trip overlap fields")
write(rel,s)

rel="frontend/src/pages/LeaderPage.tsx"
s=read(rel)
s=replace_once(s,
'''import{correctionChangeText}from"../correction-ui";
import type{BackgroundJob,CorrectionRequest,DashboardSummary,ImportPreview,ManagedLocation,Team,Trip}from"../types";''',
'''import{correctionChangeText}from"../correction-ui";
import{formatTripTime,hasLeaderTimeOverlap,leaderOverlapConfirmMessage,leaderOverlapWarningText}from"../leader-overlap";
import type{BackgroundJob,CorrectionRequest,DashboardSummary,ImportPreview,ManagedLocation,Team,Trip}from"../types";''',"LeaderPage helper import")

s=replace_once(s,
''' const approve=async(t:Trip)=>{const noMileage=t.stops.length<2;const value=noMileage?null:Number(reviewKm[t.visitTripId]||t.systemDistanceKm);if(!noMileage&&(typeof value!=='number'||!Number.isFinite(value)||value<0))return setMsg('請填寫有效的核定里程。');setBusy(true);try{await api(`/trips/${t.visitTripId}/approve`,{method:'POST',body:JSON.stringify({approvedDistanceKm:value,rowVersion:t.rowVersion,comments:noMileage?'地點不足2個，不計里程與補助。':null})});setMsg(`已核准 ${t.tripNo}`);await load()}catch(e){setMsg(e instanceof Error?e.message:'核准失敗')}finally{setBusy(false)}};''',
''' const approve=async(t:Trip)=>{const noMileage=t.stops.length<2;const value=noMileage?null:Number(reviewKm[t.visitTripId]||t.systemDistanceKm);if(!noMileage&&(typeof value!=='number'||!Number.isFinite(value)||value<0))return setMsg('請填寫有效的核定里程。');const overlapMessage=leaderOverlapConfirmMessage(t,rows);if(overlapMessage&&!window.confirm(overlapMessage))return;const comments=overlapMessage?(t.timeOverlapConfirmed?'時間重疊；外訪員已確認，小組長確認仍核准。':'時間重疊；小組長確認仍核准。'):(noMileage?'地點不足2個，不計里程與補助。':null);setBusy(true);try{await api(`/trips/${t.visitTripId}/approve`,{method:'POST',body:JSON.stringify({approvedDistanceKm:value,rowVersion:t.rowVersion,comments})});setMsg(`已核准 ${t.tripNo}`);await load()}catch(e){setMsg(e instanceof Error?e.message:'核准失敗')}finally{setBusy(false)}};''',"LeaderPage approval confirmation")

s=replace_once(s,
'''<th>日期</th><th>外訪員</th><th>小組</th><th>路線</th><th>自算</th>''',
'''<th>日期</th><th>時間</th><th>外訪員</th><th>小組</th><th>路線</th><th>自算</th>''',"LeaderPage time header")

s=replace_once(s,
'''<tbody>{rows.map(t=>{const noMileage=t.stops.length<2;return <tr key={t.visitTripId}>''',
'''<tbody>{rows.map(t=>{const noMileage=t.stops.length<2;const overlap=hasLeaderTimeOverlap(t,rows);const overlapText=leaderOverlapWarningText(t,rows);return <tr key={t.visitTripId}>''',"LeaderPage row overlap state")

s=replace_once(s,
'''</td><td>{t.visitDate}</td><td>{t.visitorName}</td><td>{t.teamName||'—'}</td>''',
'''</td><td>{t.visitDate}</td><td><div>{formatTripTime(t)}</div>{overlap&&overlapText&&<div style={{marginTop:4,fontSize:12,fontWeight:700,color:'#b45309',whiteSpace:'nowrap'}}>{overlapText}</div>}</td><td>{t.visitorName}</td><td>{t.teamName||'—'}</td>''',"LeaderPage time warning cell")
write(rel,s)

print("Leader time-overlap review fix applied successfully.")
