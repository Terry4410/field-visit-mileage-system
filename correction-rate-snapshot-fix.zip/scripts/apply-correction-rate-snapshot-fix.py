#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

repo = ROOT / "backend/src/FieldVisit.Infrastructure/V160FinalRepository.cs"
text = repo.read_text(encoding="utf-8")

old = '''        var snapshot = await GetLatestSnapshotAsync(request.VisitTripId, ct) ?? throw new InvalidOperationException("找不到核准 Snapshot。");
        // Policy values are server-owned. Recalculate the applicable rate from the corrected business date;
        // a one-stop correction remains NotApplicable. This also guarantees that a date correction which crosses
        // a rate boundary becomes a financial correction and therefore requires Admin close.
        var correctedHasMileage = request.Proposal.Stops.Count >= 2;
        decimal? correctedRate = null;
        if (correctedHasMileage)
        {
            if (request.Proposal.ClaimedDistanceKm is null or <= 0) throw new InvalidOperationException("兩個以上地點的更正必須填寫自算里程。");
            if (request.Proposal.ApprovedDistanceKm is null or < 0) throw new InvalidOperationException("兩個以上地點的更正必須填寫核定里程。");
            correctedRate = await db.MileageRateRules.AsNoTracking()
                .Where(x => x.IsActive && (x.OrganizationId == trip.OrganizationId || x.OrganizationId == null) &&
                    x.VehicleType == (snapshot.VehicleTypeSnapshot ?? "Motorcycle") && x.EffectiveFrom <= request.Proposal.VisitDate &&
                    (!x.EffectiveTo.HasValue || x.EffectiveTo >= request.Proposal.VisitDate))
                .OrderByDescending(x => x.OrganizationId.HasValue).ThenByDescending(x => x.EffectiveFrom)
                .Select(x => (decimal?)x.RatePerKm).FirstOrDefaultAsync(ct)
                ?? throw new InvalidOperationException("找不到更正日期適用的補助費率。");
        }'''

new = '''        var snapshot = await GetLatestSnapshotAsync(request.VisitTripId, ct) ?? throw new InvalidOperationException("找不到核准 Snapshot。");

        // Financial snapshot rule:
        // - Same VisitDate: preserve the frozen rate from the base approved Snapshot.
        // - Changed VisitDate: re-evaluate rate using the corrected business date.
        // - One-stop corrections remain NotApplicable.
        var correctedHasMileage = request.Proposal.Stops.Count >= 2;
        decimal? correctedRate = null;
        if (correctedHasMileage)
        {
            if (request.Proposal.ClaimedDistanceKm is null or <= 0) throw new InvalidOperationException("兩個以上地點的更正必須填寫自算里程。");
            if (request.Proposal.ApprovedDistanceKm is null or < 0) throw new InvalidOperationException("兩個以上地點的更正必須填寫核定里程。");

            if (V160CorrectionFinancialRules.ShouldPreserveSnapshotRate(
                    snapshot.VisitDate,
                    request.Proposal.VisitDate))
            {
                correctedRate = V160CorrectionFinancialRules.RequireSnapshotRate(
                    snapshot.RatePerKmSnapshot);
            }
            else
            {
                correctedRate = await db.MileageRateRules.AsNoTracking()
                    .Where(x => x.IsActive && (x.OrganizationId == trip.OrganizationId || x.OrganizationId == null) &&
                        x.VehicleType == (snapshot.VehicleTypeSnapshot ?? "Motorcycle") && x.EffectiveFrom <= request.Proposal.VisitDate &&
                        (!x.EffectiveTo.HasValue || x.EffectiveTo >= request.Proposal.VisitDate))
                    .OrderByDescending(x => x.OrganizationId.HasValue).ThenByDescending(x => x.EffectiveFrom)
                    .Select(x => (decimal?)x.RatePerKm).FirstOrDefaultAsync(ct)
                    ?? throw new InvalidOperationException("找不到更正日期適用的補助費率。");
            }
        }'''

if new in text:
    print("V160FinalRepository.cs: already patched")
elif old not in text:
    raise SystemExit("V160FinalRepository.cs: target block not found; stop")
else:
    repo.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("V160FinalRepository.cs: patched")

helper = ROOT / "backend/src/FieldVisit.Application/V160CorrectionFinancialRules.cs"
helper_content = '''namespace FieldVisit.Application;

public static class V160CorrectionFinancialRules
{
    public static bool ShouldPreserveSnapshotRate(
        DateOnly baseVisitDate,
        DateOnly proposedVisitDate)
        => baseVisitDate == proposedVisitDate;

    public static decimal RequireSnapshotRate(decimal? snapshotRate)
        => snapshotRate
           ?? throw new InvalidOperationException(
               "原核准 Snapshot 缺少補助費率，無法進行財務更正。");

    public static decimal CalculateSubsidy(
        decimal approvedDistanceKm,
        decimal ratePerKm)
        => decimal.Round(approvedDistanceKm * ratePerKm, 2);
}
'''
if helper.exists() and helper.read_text(encoding="utf-8") != helper_content:
    raise SystemExit("V160CorrectionFinancialRules.cs exists with different content; stop")
helper.write_text(helper_content, encoding="utf-8")
print("V160CorrectionFinancialRules.cs: ready")

tests = ROOT / "backend/tests/FieldVisit.Application.Tests/V160CorrectionFinancialRulesTests.cs"
test_content = '''using FieldVisit.Application;
using Xunit;

namespace FieldVisit.Application.Tests;

public sealed class V160CorrectionFinancialRulesTests
{
    [Fact]
    public void SameVisitDate_PreservesFrozenSnapshotRate()
    {
        Assert.True(
            V160CorrectionFinancialRules.ShouldPreserveSnapshotRate(
                new DateOnly(2026, 8, 18),
                new DateOnly(2026, 8, 18)));

        Assert.Equal(
            3.00m,
            V160CorrectionFinancialRules.RequireSnapshotRate(3.00m));
    }

    [Fact]
    public void ChangedVisitDate_ReevaluatesRate()
    {
        Assert.False(
            V160CorrectionFinancialRules.ShouldPreserveSnapshotRate(
                new DateOnly(2026, 8, 18),
                new DateOnly(2026, 8, 19)));
    }

    [Fact]
    public void CorrectedMileage_UsesFrozenRateForAmount()
    {
        Assert.Equal(
            57.00m,
            V160CorrectionFinancialRules.CalculateSubsidy(19.0m, 3.00m));
    }

    [Fact]
    public void MissingSnapshotRate_IsRejected()
    {
        Assert.Throws<InvalidOperationException>(
            () => V160CorrectionFinancialRules.RequireSnapshotRate(null));
    }
}
'''
if tests.exists() and tests.read_text(encoding="utf-8") != test_content:
    raise SystemExit("V160CorrectionFinancialRulesTests.cs exists with different content; stop")
tests.write_text(test_content, encoding="utf-8")
print("V160CorrectionFinancialRulesTests.cs: ready")
print("Correction financial snapshot rule fix completed.")
