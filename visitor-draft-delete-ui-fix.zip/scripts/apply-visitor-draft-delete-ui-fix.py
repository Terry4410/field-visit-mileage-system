#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "frontend/src/pages/UnifiedQueryPage.tsx"
text = path.read_text(encoding="utf-8")

old_import = 'import type{CorrectionDraft,CorrectionProposal,PagedResult,Project,Team,TripQueryRow,UserOption,VisitType}from"../types";'
new_import = 'import type{CorrectionDraft,CorrectionProposal,PagedResult,Project,Team,Trip,TripQueryRow,UserOption,VisitType}from"../types";'
if new_import not in text:
    if old_import not in text: raise SystemExit('UnifiedQueryPage import marker not found.')
    text = text.replace(old_import, new_import, 1)

marker = " const submitCorrection=async()=>{if(!correction)return;if(!reason.trim()){setCorrectionError('請填寫更正原因。');return}setBusy(true);setCorrectionError('');try{await api('/corrections',{method:'POST',body:JSON.stringify({visitTripId:correction.visitTripId,reason:reason.trim(),proposal:correction.proposal})});setCorrection(null);setCorrectionError('');setMsg('更正申請已送出，等待小組長審核。');await load(page)}catch(e){setCorrectionError(e instanceof Error?e.message:'更正申請失敗')}finally{setBusy(false)}};"
delete_fn = "\n".join([
    " const deleteDraft=async(row:TripQueryRow)=>{",
    "  if(activeRole!=='visitor'||row.status!=='Draft')return;",
    "  const confirmed=window.confirm(`確定要刪除草稿 ${row.tripNo}？\\n\\n刪除後不可復原；若草稿使用的臨時地點沒有被其他有效行程使用，系統也會一併取消該臨時地點。`);",
    "  if(!confirmed)return;",
    "  setBusy(true);setMsg('');",
    "  try{",
    "   const latest=await api<Trip>(`/trips/${row.visitTripId}`);",
    "   if(latest.status!=='Draft')throw new Error('此行程已不是草稿，請重新整理後再操作。');",
    "   await api<void>(`/trips/${row.visitTripId}`,{method:'DELETE',headers:{'If-Match':latest.rowVersion}});",
    "   if(detail?.visitTripId===row.visitTripId)setDetail(null);",
    "   setMsg(`草稿 ${row.tripNo} 已刪除。`);",
    "   await load(page);",
    "  }catch(e){setMsg(e instanceof Error?e.message:'刪除草稿失敗')}",
    "  finally{setBusy(false)}",
    " };",
])
if 'const deleteDraft=async(row:TripQueryRow)' not in text:
    if marker not in text: raise SystemExit('deleteDraft insertion marker not found.')
    text = text.replace(marker, marker + '\n' + delete_fn, 1)

old_actions = "{allowCorrection&&(r.status==='Draft'||r.status==='Returned')&&<button className=\"btn small secondary\" onClick={()=>navigate(`/?edit=${r.visitTripId}`)}>{r.status==='Returned'?'修改後重送':'繼續編輯／送出'}</button>}<button className=\"btn small outline\" onClick={()=>setDetail(r)}>查看</button>"
new_actions = "{allowCorrection&&(r.status==='Draft'||r.status==='Returned')&&<button className=\"btn small secondary\" onClick={()=>navigate(`/?edit=${r.visitTripId}`)}>{r.status==='Returned'?'修改後重送':'繼續編輯／送出'}</button>}{allowCorrection&&activeRole==='visitor'&&r.status==='Draft'&&<button className=\"btn small danger\" onClick={()=>void deleteDraft(r)} disabled={busy}>刪除草稿</button>}<button className=\"btn small outline\" onClick={()=>setDetail(r)}>查看</button>"
if new_actions not in text:
    if old_actions not in text: raise SystemExit('table action marker not found.')
    text = text.replace(old_actions, new_actions, 1)

old_detail = "{allowCorrection&&(detail.status==='Draft'||detail.status==='Returned')&&<button className=\"btn ok\" onClick={()=>{const id=detail.visitTripId;setDetail(null);navigate(`/?edit=${id}`)}}>{detail.status==='Returned'?'修改後重送':'繼續編輯／送出'}</button>}<button className=\"btn\" onClick={()=>setDetail(null)}>關閉</button>"
new_detail = "{allowCorrection&&(detail.status==='Draft'||detail.status==='Returned')&&<button className=\"btn ok\" onClick={()=>{const id=detail.visitTripId;setDetail(null);navigate(`/?edit=${id}`)}}>{detail.status==='Returned'?'修改後重送':'繼續編輯／送出'}</button>}{allowCorrection&&activeRole==='visitor'&&detail.status==='Draft'&&<button className=\"btn danger\" onClick={()=>void deleteDraft(detail)} disabled={busy}>刪除草稿</button>}<button className=\"btn\" onClick={()=>setDetail(null)}>關閉</button>"
if new_detail not in text:
    if old_detail not in text: raise SystemExit('detail action marker not found.')
    text = text.replace(old_detail, new_detail, 1)

path.write_text(text, encoding="utf-8")
print('UnifiedQueryPage draft-delete UI patched successfully.')