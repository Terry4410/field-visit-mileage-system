#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "backend/src/FieldVisit.Application/MasterAndReportServices.cs"
text = path.read_text(encoding="utf-8")

old = """        row.LocationName = request.LocationName.Trim();
        row.City = request.City;
        row.District = request.District;
        row.Address = request.Address;
        row.PlusCode = request.PlusCode;
        row.GeocodingStatus = "Pending";
        row.UpdatedAt = DateTime.UtcNow;
"""

new = """        var normalizedAddress =
            V170LocationGeocodingRules.Normalize(request.Address);
        var normalizedPlusCode =
            V170LocationGeocodingRules.Normalize(request.PlusCode);

        var geocodingInputChanged =
            V170LocationGeocodingRules.GeocodingInputChanged(
                row.Address,
                row.PlusCode,
                normalizedAddress,
                normalizedPlusCode);

        row.LocationName = request.LocationName.Trim();
        row.City = request.City;
        row.District = request.District;
        row.Address = normalizedAddress;
        row.PlusCode = normalizedPlusCode;

        // Location name / descriptive edits must not invalidate coordinates.
        // Only inputs actually used by IGeocodingService require re-geocoding.
        if (geocodingInputChanged)
        {
            row.GeocodingStatus = "Pending";
        }

        row.UpdatedAt = DateTime.UtcNow;
"""

if new in text:
    print("MasterService.UpdateLocationAsync already patched.")
elif old not in text:
    raise SystemExit(
        "UpdateLocationAsync marker not found. Stop to avoid patching the wrong version."
    )
else:
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("MasterService.UpdateLocationAsync patched successfully.")
