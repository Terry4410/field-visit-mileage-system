from pathlib import Path

repo = Path('.')

def replace_method(path: Path, start_marker: str, end_marker: str, new_text: str, label: str):
    text = path.read_text(encoding='utf-8')
    start = text.find(start_marker)
    end = text.find(end_marker, start)
    if start < 0 or end < 0:
        raise SystemExit(f'{label}: 找不到方法邊界，停止避免錯改。')
    text = text[:start] + new_text + text[end:]
    path.write_text(text, encoding='utf-8')
    print(f'{label}: patched')

trip_path = repo/'backend/src/FieldVisit.Application/TripService.cs'
new_submit = '''    public async Task<TripDto> SubmitAsync(long tripId, SubmitTripRequest request, string rowVersion, CancellationToken ct)
    {
        var user = RequireRole("visitor");
        var trip = await trips.GetAsync(tripId, true, ct)
            ?? throw new KeyNotFoundException("找不到行程。");

        EnsureVisitorOwns(user, trip);
        if (trip.Status is not (TripStatuses.Draft or TripStatuses.Returned))
            throw new InvalidOperationException("此狀態不能送出。");
        EnsureRowVersion(trip.RowVersion, rowVersion);

        if (trip.StartTime is null || trip.EndTime is null)
            throw new InvalidOperationException("送出前必須填寫起訖時間。");

        var calc = await mileage.GetByTripAsync(trip.VisitTripId, true, ct);
        V170TripMileageRules.EnsureReadyForSubmission(
            trip.Stops.Count,
            calc?.ClaimedDistanceKm);

        var overlap = await CheckOverlapAsync(new TimeOverlapRequest(
            trip.VisitDate, trip.StartTime.Value, trip.EndTime.Value, trip.VisitTripId), ct);
        if (overlap.HasOverlap && !request.ConfirmTimeOverlap)
            throw new InvalidOperationException("TIME_OVERLAP_WARNING：請確認時間重疊後再送出。");

        var previous = trip.Status;
        trip.Status = TripStatuses.Submitted;
        trip.HasTimeOverlapWarning = overlap.HasOverlap;
        trip.TimeOverlapConfirmed = overlap.HasOverlap && request.ConfirmTimeOverlap;
        trip.SubmittedAt = DateTime.UtcNow;
        trip.ReturnReason = null;
        trip.UpdatedAt = DateTime.UtcNow;
        trip.UpdatedByUserId = user.UserId;

        await AddHistoryAsync(
            trip,
            previous,
            TripStatuses.Submitted,
            previous == TripStatuses.Returned ? "Resubmit" : "Submit",
            user.UserId,
            overlap.HasOverlap ? "使用者已確認時間重疊" : null,
            ct);
        await AuditAsync(user.UserId, "Trip", trip.VisitTripId.ToString(), "TripSubmit", null, new { trip.TripNo }, ct);
        await uow.SaveChangesAsync(ct);
        return await GetDtoAsync(tripId, ct);
    }

'''
replace_method(
    trip_path,
    '    public async Task<TripDto> SubmitAsync(',
    '    public async Task<TimeOverlapResult> CheckOverlapAsync(',
    new_submit,
    'TripService.SubmitAsync')

leader_path = repo/'backend/src/FieldVisit.Application/LeaderService.cs'
new_approve = '''    public async Task<TripDto> ApproveAsync(long tripId, ApproveTripRequest request, CancellationToken ct)
    {
        var user = RequireLeader();
        var trip = await GetScopedAsync(tripId, user, ct);
        if (trip.Status != TripStatuses.PendingApproval)
            throw new InvalidOperationException("只有待核准行程可以核准。");
        EnsureRowVersion(trip.RowVersion, request.RowVersion);

        V170TripMileageRules.EnsureReadyForApproval(trip.Stops.Count);

        if (request.ApprovedDistanceKm is null or <= 0)
            throw new InvalidOperationException("兩個以上地點的行程必須填寫大於 0 的核定里程。");

        var calc = await mileage.GetByTripAsync(tripId, true, ct);
        if (calc is null)
        {
            calc = new MileageCalculation { VisitTripId = tripId, CreatedAt = DateTime.UtcNow };
            await mileage.AddAsync(calc, ct);
        }

        var rate = await mileage.GetEffectiveRateAsync(
            trip.OrganizationId,
            trip.VehicleType ?? "Motorcycle",
            trip.VisitDate,
            ct)
            ?? throw new InvalidOperationException("找不到行程日期適用的補助費率。");

        var previous = trip.Status;
        trip.Status = TripStatuses.Approved;
        trip.ApprovedAt = DateTime.UtcNow;
        trip.ReturnReason = null;
        trip.UpdatedAt = DateTime.UtcNow;
        trip.UpdatedByUserId = user.UserId;

        calc.MileageRateRuleId = rate.MileageRateRuleId;
        calc.ApprovedDistanceKm = request.ApprovedDistanceKm;
        calc.RatePerKmSnapshot = rate.RatePerKm;
        calc.ClaimedAmount = calc.ClaimedDistanceKm.HasValue
            ? decimal.Round(calc.ClaimedDistanceKm.Value * rate.RatePerKm, 2)
            : null;
        calc.ApprovedAmount = decimal.Round(request.ApprovedDistanceKm.Value * rate.RatePerKm, 2);
        calc.UpdatedAt = DateTime.UtcNow;

        await workflow.AddApprovalAsync(new ApprovalRecord
        {
            VisitTripId = trip.VisitTripId,
            ApprovalStep = 1,
            ApproverUserId = user.UserId,
            Action = "Approved",
            Comments = request.Comments,
            ActionAt = DateTime.UtcNow
        }, ct);
        await workflow.AddStatusHistoryAsync(new VisitTripStatusHistory
        {
            VisitTripId = trip.VisitTripId,
            PreviousStatus = previous,
            NewStatus = TripStatuses.Approved,
            Action = "Approve",
            ActionByUserId = user.UserId,
            Comments = $"ApprovedKm={request.ApprovedDistanceKm};Rate={rate.RatePerKm};Amount={calc.ApprovedAmount}",
            ActionAt = DateTime.UtcNow
        }, ct);
        await workflow.AddAuditAsync(Audit(
            user.UserId,
            trip.VisitTripId,
            "TripApprove",
            new
            {
                ApprovedDistanceKm = request.ApprovedDistanceKm,
                RatePerKm = rate.RatePerKm,
                calc.ApprovedAmount
            }), ct);

        await snapshots.AddApprovedSnapshotAsync(trip, user, ct);
        await uow.SaveChangesAsync(ct);
        return await tripService.GetDtoAsync(tripId, ct);
    }

'''
replace_method(
    leader_path,
    '    public async Task<TripDto> ApproveAsync(',
    '    public async Task<TripDto> ReturnAsync(',
    new_approve,
    'LeaderService.ApproveAsync')

visitor_path = repo/'frontend/src/pages/VisitorPage.tsx'
text = visitor_path.read_text(encoding='utf-8')
old_import = 'import SmartLocationPicker from "../components/SmartLocationPicker";\n'
new_import = old_import + 'import {validateTripMileageForSubmit} from "../trip-submit-rules";\n'
if 'from "../trip-submit-rules"' not in text:
    if old_import not in text:
        raise SystemExit('VisitorPage import marker not found')
    text = text.replace(old_import, new_import, 1)

old_validate = '''  const validateForSubmit=()=>{
    if(stops.length<1){setMsg("送出前至少需要一個公務地點。");return false}
    if(stops.length>=2&&Number(km)<=0){setMsg("兩個以上地點的行程，送出前請填寫外訪員自行計算里程。");return false}
    if(end<=start){setMsg("結束時間必須晚於出發時間。");return false}
    return true;
  };'''
new_validate = '''  const validateForSubmit=()=>{
    const mileageError=validateTripMileageForSubmit(stops.length,km);
    if(mileageError){setMsg(mileageError);return false}
    if(end<=start){setMsg("結束時間必須晚於出發時間。");return false}
    return true;
  };'''
if old_validate not in text:
    raise SystemExit('VisitorPage validateForSubmit marker not found')
text = text.replace(old_validate, new_validate, 1)

old_body = 'claimedDistanceKm:stops.length>=2?(Number(km)||0):null'
new_body = 'claimedDistanceKm:stops.length>=2&&km.trim()?Number(km):null'
if old_body not in text:
    raise SystemExit('VisitorPage claimedDistanceKm marker not found')
text = text.replace(old_body, new_body, 1)

old_hint = '{stops.length<2?"地點不足 2 個，不計里程":"送出前填寫"}'
new_hint = '{stops.length<2?"至少 2 個公務地點才可正式送出":"正式送出前必填"}'
if old_hint not in text:
    raise SystemExit('VisitorPage mileage hint marker not found')
text = text.replace(old_hint, new_hint, 1)

visitor_path.write_text(text, encoding='utf-8')
print('VisitorPage: patched')
