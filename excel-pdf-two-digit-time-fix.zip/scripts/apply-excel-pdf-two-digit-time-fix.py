from pathlib import Path

path = Path("backend/src/FieldVisit.Infrastructure/ReportDocumentService.cs")
if not path.exists():
    raise SystemExit(f"找不到 {path}；請從 repository root 執行。")

text = path.read_text(encoding="utf-8")

def replace_once(old, new, label, required=True):
    global text
    if new in text:
        print(f"{label}: already patched")
        return
    if old not in text:
        if required:
            raise SystemExit(f"{label}: 找不到預期內容；停止，避免錯改。")
        print(f"{label}: source pattern not found; skipped")
        return
    text = text.replace(old, new, 1)
    print(f"{label}: patched")

# A. Excel: split single "時間" column if the previous patch has not yet been applied.
replace_once(
    'yield return new object?[] { "日期", "時間", "TripNo", "外訪員", "員編", "小組", "專案", "拜訪形式", "拜訪順序", "自算里程", "系統里程", "核定里程", "每公里補助", "補助金額", "狀態", "Snapshot版本", "更正狀態", "備註" };',
    'yield return new object?[] { "日期", "起始時", "起始分", "結束時", "結束分", "TripNo", "外訪員", "員編", "小組", "專案", "拜訪形式", "拜訪順序", "自算里程", "系統里程", "核定里程", "每公里補助", "補助金額", "狀態", "Snapshot版本", "更正狀態", "備註" };',
    "Excel summary headers",
    required=False
)

replace_once(
    'foreach (var r in rows) yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), TimeRange(r.StartTime, r.EndTime), r.TripNo, r.VisitorName, r.EmployeeNo, r.TeamName, r.ProjectNames, r.VisitTypeNames, r.Route, r.ClaimedDistanceKm, r.SystemDistanceKm, r.ApprovedDistanceKm, r.RatePerKmSnapshot, r.SubsidyAmount, r.StatusName, r.SnapshotVersion, r.CorrectionStatus, r.Notes };',
    'foreach (var r in rows) yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), r.StartTime?.Hour, r.StartTime?.Minute, r.EndTime?.Hour, r.EndTime?.Minute, r.TripNo, r.VisitorName, r.EmployeeNo, r.TeamName, r.ProjectNames, r.VisitTypeNames, r.Route, r.ClaimedDistanceKm, r.SystemDistanceKm, r.ApprovedDistanceKm, r.RatePerKmSnapshot, r.SubsidyAmount, r.StatusName, r.SnapshotVersion, r.CorrectionStatus, r.Notes };',
    "Excel summary rows",
    required=False
)

replace_once(
    'yield return new object?[] { "日期", "時間", "TripNo", "外訪員", "小組", "順序", "地點代碼", "地點名稱", "地址", "專案代碼", "專案名稱", "拜訪形式代碼", "拜訪形式", "行程目的", "備註" };',
    'yield return new object?[] { "日期", "起始時", "起始分", "結束時", "結束分", "TripNo", "外訪員", "小組", "順序", "地點代碼", "地點名稱", "地址", "專案代碼", "專案名稱", "拜訪形式代碼", "拜訪形式", "行程目的", "備註" };',
    "Excel stop headers",
    required=False
)

replace_once(
    'yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), TimeRange(r.StartTime, r.EndTime), r.TripNo, r.VisitorName, r.TeamName, s.StopSequence, s.LocationCode, s.LocationName, s.Address, s.ProjectCode, s.ProjectName, s.VisitTypeCode, s.VisitTypeName, s.VisitPurpose, s.Notes };',
    'yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), r.StartTime?.Hour, r.StartTime?.Minute, r.EndTime?.Hour, r.EndTime?.Minute, r.TripNo, r.VisitorName, r.TeamName, s.StopSequence, s.LocationCode, s.LocationName, s.Address, s.ProjectCode, s.ProjectName, s.VisitTypeCode, s.VisitTypeName, s.VisitPurpose, s.Notes };',
    "Excel stop rows",
    required=False
)

# B. Excel workbook: add style table for numeric 00 display.
replace_once(
    '''            var workbookPart = doc.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();
            var sheets = workbookPart.Workbook.AppendChild(new Sheets());''',
    '''            var workbookPart = doc.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();
            AddWorkbookStyles(workbookPart);
            var sheets = workbookPart.Workbook.AppendChild(new Sheets());''',
    "Excel workbook styles call"
)

old_methods = '''    private static void AddWorksheet(WorkbookPart workbookPart, Sheets sheets, uint sheetId, string name, IEnumerable<IReadOnlyList<object?>> rows)
    {
        var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
        var sheetData = new SheetData();
        foreach (var values in rows)
        {
            var row = new Row();
            foreach (var value in values) row.Append(ToCell(value));
            sheetData.Append(row);
        }
        worksheetPart.Worksheet = new Worksheet(sheetData);
        worksheetPart.Worksheet.Save();
        sheets.Append(new Sheet { Id = workbookPart.GetIdOfPart(worksheetPart), SheetId = sheetId, Name = name });
    }

    private static Cell ToCell(object? value)
    {
        if (value is null) return new Cell { DataType = CellValues.InlineString, InlineString = new InlineString(new Text("")) };
        if (value is byte or short or int or long or float or double or decimal)
            return new Cell { DataType = CellValues.Number, CellValue = new CellValue(Convert.ToString(value, System.Globalization.CultureInfo.InvariantCulture)) };
        if (value is bool b) return new Cell { DataType = CellValues.Boolean, CellValue = new CellValue(b ? "1" : "0") };
        return new Cell { DataType = CellValues.InlineString, InlineString = new InlineString(new Text(value.ToString() ?? "")) };
    }'''

new_methods = '''    private static void AddWorksheet(WorkbookPart workbookPart, Sheets sheets, uint sheetId, string name, IEnumerable<IReadOnlyList<object?>> rows)
    {
        var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
        var sheetData = new SheetData();
        var materialized = rows.ToList();

        var twoDigitColumns = new HashSet<int>();
        if (materialized.Count > 0)
        {
            var header = materialized[0];
            for (var i = 0; i < header.Count; i++)
            {
                var label = header[i]?.ToString();
                if (label is "起始時" or "起始分" or "結束時" or "結束分")
                    twoDigitColumns.Add(i);
            }
        }

        for (var rowIndex = 0; rowIndex < materialized.Count; rowIndex++)
        {
            var values = materialized[rowIndex];
            var row = new Row();

            for (var columnIndex = 0; columnIndex < values.Count; columnIndex++)
            {
                var useTwoDigitStyle =
                    rowIndex > 0
                    && twoDigitColumns.Contains(columnIndex);

                row.Append(
                    ToCell(
                        values[columnIndex],
                        useTwoDigitStyle ? 1U : null));
            }

            sheetData.Append(row);
        }

        worksheetPart.Worksheet = new Worksheet(sheetData);
        worksheetPart.Worksheet.Save();
        sheets.Append(new Sheet { Id = workbookPart.GetIdOfPart(worksheetPart), SheetId = sheetId, Name = name });
    }

    private static void AddWorkbookStyles(WorkbookPart workbookPart)
    {
        var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();

        var numberingFormats = new NumberingFormats(
            new NumberingFormat
            {
                NumberFormatId = 164U,
                FormatCode = "00"
            })
        {
            Count = 1U
        };

        var fonts = new Fonts(new Font()) { Count = 1U };

        var fills = new Fills(
            new Fill(new PatternFill { PatternType = PatternValues.None }),
            new Fill(new PatternFill { PatternType = PatternValues.Gray125 }))
        {
            Count = 2U
        };

        var borders = new Borders(new Border()) { Count = 1U };

        var cellStyleFormats = new CellStyleFormats(
            new CellFormat())
        {
            Count = 1U
        };

        var cellFormats = new CellFormats(
            new CellFormat(),
            new CellFormat
            {
                NumberFormatId = 164U,
                ApplyNumberFormat = true
            })
        {
            Count = 2U
        };

        stylesPart.Stylesheet = new Stylesheet(
            numberingFormats,
            fonts,
            fills,
            borders,
            cellStyleFormats,
            cellFormats);

        stylesPart.Stylesheet.Save();
    }

    private static Cell ToCell(object? value, uint? styleIndex = null)
    {
        Cell cell;

        if (value is null)
        {
            cell = new Cell
            {
                DataType = CellValues.InlineString,
                InlineString = new InlineString(new Text(""))
            };
        }
        else if (value is byte or short or int or long or float or double or decimal)
        {
            cell = new Cell
            {
                DataType = CellValues.Number,
                CellValue = new CellValue(
                    Convert.ToString(
                        value,
                        System.Globalization.CultureInfo.InvariantCulture))
            };
        }
        else if (value is bool b)
        {
            cell = new Cell
            {
                DataType = CellValues.Boolean,
                CellValue = new CellValue(b ? "1" : "0")
            };
        }
        else
        {
            cell = new Cell
            {
                DataType = CellValues.InlineString,
                InlineString = new InlineString(
                    new Text(value.ToString() ?? ""))
            };
        }

        if (styleIndex.HasValue)
            cell.StyleIndex = styleIndex.Value;

        return cell;
    }'''

replace_once(
    old_methods,
    new_methods,
    "Excel two-digit numeric style"
)

# C. PDF: make the 2-digit output explicit.
replace_once(
    '''    private static string TimeRange(TimeOnly? start, TimeOnly? end)
    {
        var s = start?.ToString("HH:mm");
        var e = end?.ToString("HH:mm");
        if (s is not null && e is not null) return $"{s}～{e}";
        if (s is not null) return $"{s}～—";
        if (e is not null) return $"—～{e}";
        return "—";
    }''',
    '''    private static string TimeRange(TimeOnly? start, TimeOnly? end)
    {
        var s = start.HasValue
            ? $"{start.Value.Hour:00}:{start.Value.Minute:00}"
            : null;

        var e = end.HasValue
            ? $"{end.Value.Hour:00}:{end.Value.Minute:00}"
            : null;

        if (s is not null && e is not null) return $"{s}～{e}";
        if (s is not null) return $"{s}～—";
        if (e is not null) return $"—～{e}";
        return "—";
    }''',
    "PDF explicit two-digit time"
)

path.write_text(text, encoding="utf-8")
print("Two-digit Excel/PDF time formatting applied successfully.")
