#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "frontend/src/pages/UnifiedQueryPage.tsx"
text = path.read_text(encoding="utf-8")

old_submit = "setCorrection(null);setCorrectionError('');setMsg('更正申請已送出，等待小組長審核。');await load(page)"
new_submit = "setCorrection(null);setCorrectionError('');await load(page);setMsg('更正申請已送出，等待小組長審核。')"

if new_submit not in text:
    if old_submit not in text:
        raise SystemExit('submitCorrection success-message marker not found.')
    text = text.replace(old_submit, new_submit, 1)

old_delete = "setMsg(`草稿 ${row.tripNo} 已刪除。`);\n   await load(page);"
new_delete = "await load(page);\n   setMsg(`草稿 ${row.tripNo} 已刪除。`);"

if new_delete not in text:
    if old_delete not in text:
        raise SystemExit('deleteDraft success-message marker not found.')
    text = text.replace(old_delete, new_delete, 1)

path.write_text(text, encoding='utf-8')
print('UnifiedQueryPage success-message ordering fixed successfully.')
