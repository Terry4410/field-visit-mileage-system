#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / "backend/src/FieldVisit.Infrastructure/WorkbookImportService.cs"
text = p.read_text(encoding="utf-8")

def replace_once(old: str, new: str, label: str):
    global text
    if new in text:
        print(f"{label}: already patched")
        return
    if old not in text:
        raise SystemExit(f"{label}: marker not found; stop to avoid patching wrong version")
    text = text.replace(old, new, 1)
    print(f"{label}: patched")

# 1. New Location workbook: remove misleading Status column and add help sheet.
replace_once(
'''            if (importType == "locations")
            {
                AddSheet(wb, sheets, 1, "Locations", new[]
                {
                    new[] { "LocationCode", "TeamCode", "LocationName", "City", "District", "Address", "PlusCode", "Status" },
                    new[] { "", "TEAM-N01", "客戶A", "台北市", "內湖區", "台北市內湖區示例路1號", "", "Active" }
                });
            }''',
'''            if (importType == "locations")
            {
                AddSheet(wb, sheets, 1, "Locations", new[]
                {
                    new[] { "LocationCode", "TeamCode", "LocationName", "City", "District", "Address", "PlusCode" },
                    new[] { "", "TEAM-N01", "客戶A", "台北市", "內湖區", "台北市內湖區示例路1號", "" }
                });
                AddSheet(wb, sheets, 2, "說明", new[]
                {
                    new[] { "項目", "規則" },
                    new[] { "LocationCode", "新增地點請留空；更新既有地點時必須填寫現有 LocationCode。" },
                    new[] { "TeamCode", "選填；若填寫必須是目前啟用且有權限的小組代碼。" },
                    new[] { "LocationName", "必填。" },
                    new[] { "Address / PlusCode", "至少需填一項。" },
                    new[] { "新增地點", "Excel 匯入後一律為正式地點資料，但 ApprovalStatus=Pending、GeocodingStatus=Pending、IsActive=false；完成解析與核准後才可使用。" },
                    new[] { "更新既有地點", "只要主檔內容有變更，匯入後會重新進入 Pending / Pending / 未啟用，需重新解析與核准。" },
                    new[] { "重複資料", "同一 Excel 不可重複使用相同 LocationCode；新增資料不可在同一小組重複相同地點名稱＋地址／PlusCode。" },
                    new[] { "Status", "新版範本已移除。舊版檔案若仍有 Status 欄可相容讀取，但不會直接控制啟用或核准狀態。" }
                });
            }''',
"location template"
)

# 2. Replace PreviewLocationsAsync with duplicate-aware and idempotent preview logic.
pattern = re.compile(
    r'''    private async Task PreviewLocationsAsync\(SpreadsheetDocument doc, CurrentUserDto user, ImportBatch batch, List<ImportPreviewItemDto> preview, CancellationToken ct\)\n    \{.*?\n    \}\n\n    private async Task PreviewProjectsAsync''',
    re.S,
)

new_method = r'''    private async Task PreviewLocationsAsync(SpreadsheetDocument doc, CurrentUserDto user, ImportBatch batch, List<ImportPreviewItemDto> preview, CancellationToken ct)
    {
        var rows = ReadSheet(doc, "Locations");
        var workbookLocationCodes =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var workbookNewLocationKeys =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        var rowNo = 1;
        foreach (var raw in rows.Skip(1))
        {
            rowNo++;
            if (raw.All(string.IsNullOrWhiteSpace)) continue;

            var headers = rows[0];
            var data = new LocationImportRow(
                Get(raw, headers, "LocationCode", "地點代碼"),
                Get(raw, headers, "TeamCode", "小組代碼"),
                Get(raw, headers, "LocationName", "地點名稱") ?? "",
                Get(raw, headers, "City", "縣市"),
                Get(raw, headers, "District", "鄉鎮區"),
                Get(raw, headers, "Address", "地址"),
                Get(raw, headers, "PlusCode", "Plus Code"),
                // Legacy column compatibility only. Location Status never
                // bypasses geocoding / approval during Confirm.
                Get(raw, headers, "Status", "狀態") ?? "Active");

            var error = await ValidateLocationAsync(user, data, ct);
            var action = "Create";
            var code = data.LocationCode?.Trim();
            int? teamId = null;

            if (error is null)
            {
                teamId = await ResolveTeamIdAsync(user, data.TeamCode, ct);

                if (!string.IsNullOrWhiteSpace(code))
                {
                    if (!workbookLocationCodes.Add(code))
                    {
                        error = $"Excel 內 LocationCode 重複：{code}。";
                    }
                    else
                    {
                        var existing = await db.Locations
                            .AsNoTracking()
                            .FirstOrDefaultAsync(
                                x => x.OrganizationId == user.OrganizationId
                                     && x.LocationCode == code,
                                ct);

                        if (existing is null)
                        {
                            error = "LocationCode 不存在；新增地點請留空 LocationCode。";
                        }
                        else
                        {
                            action =
                                SameLocation(existing, data)
                                && existing.TeamId == teamId
                                    ? "NoChange"
                                    : "Update";
                        }
                    }
                }
                else
                {
                    var newLocationKey =
                        $"{teamId?.ToString(CultureInfo.InvariantCulture) ?? "ALL"}|"
                        + $"{data.LocationName.Trim()}|"
                        + $"{(data.Address ?? "").Trim()}|"
                        + $"{(data.PlusCode ?? "").Trim()}";

                    if (!workbookNewLocationKeys.Add(newLocationKey))
                    {
                        error =
                            "Excel 內有重複新增地點：同一小組的地點名稱與地址／PlusCode 相同。";
                    }
                    else
                    {
                        var same = await db.Locations
                            .AsNoTracking()
                            .FirstOrDefaultAsync(
                                x => x.OrganizationId == user.OrganizationId
                                     && x.TeamId == teamId
                                     && x.LocationName == data.LocationName
                                     && x.Address == data.Address
                                     && x.PlusCode == data.PlusCode,
                                ct);

                        if (same is not null)
                        {
                            // Re-uploading the same new-location row is
                            // idempotent and must not create a duplicate.
                            action = "NoChange";
                        }
                        else if (await db.Locations
                                     .AsNoTracking()
                                     .AnyAsync(
                                         x => x.OrganizationId == user.OrganizationId
                                              && x.TeamId == teamId
                                              && x.LocationName == data.LocationName,
                                         ct))
                        {
                            error =
                                "同小組已有相同地點名稱；若要更新既有地點，請先下載資料並使用 LocationCode。";
                        }
                    }
                }
            }

            await StageAsync(
                batch,
                preview,
                rowNo,
                "Location",
                action,
                code ?? data.LocationName,
                data,
                error,
                ct);
        }
    }

    private async Task PreviewProjectsAsync'''

m = pattern.search(text)
if not m:
    raise SystemExit("PreviewLocationsAsync marker not found; stop to avoid patching wrong version")

if "workbookNewLocationKeys" in m.group(0):
    print("PreviewLocationsAsync: already patched")
else:
    text = pattern.sub(new_method, text, count=1)
    print("PreviewLocationsAsync: patched")

# 3. Add explanatory comments in Confirm without changing existing lifecycle.
replace_once(
'''                    if (item.Action == "Create")
                    {
                        var teamId = await ResolveTeamIdAsync(user, data.TeamCode, ct);
                        await db.Locations.AddAsync(new FieldVisit.Domain.Entities.Location
                        {''',
'''                    if (item.Action == "Create")
                    {
                        var teamId = await ResolveTeamIdAsync(user, data.TeamCode, ct);
                        // Excel imports can never bypass the location lifecycle:
                        // new Locations always require geocoding and approval.
                        await db.Locations.AddAsync(new FieldVisit.Domain.Entities.Location
                        {''',
"create lifecycle comment"
)

replace_once(
'''                    else
                    {
                        var row = await db.Locations.FirstAsync(x => x.OrganizationId == user.OrganizationId && x.LocationCode == data.LocationCode, ct);
                        EnsureLeaderTeam(user, row.TeamId);''',
'''                    else
                    {
                        var row = await db.Locations.FirstAsync(x => x.OrganizationId == user.OrganizationId && x.LocationCode == data.LocationCode, ct);
                        EnsureLeaderTeam(user, row.TeamId);
                        // Any imported master-data change reopens geocoding /
                        // approval before the Location can be used again.''',
"update lifecycle comment"
)

p.write_text(text, encoding="utf-8")
print("Location workbook import alignment completed.")
