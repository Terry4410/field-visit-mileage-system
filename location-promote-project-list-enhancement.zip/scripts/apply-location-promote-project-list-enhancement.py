#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def replace_once(path, old, new, label):
    text = path.read_text(encoding="utf-8")
    if new in text:
        print(f"{label}: already patched")
        return
    if old not in text:
        raise SystemExit(f"{label}: marker not found")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"{label}: patched")

# Contracts
p = ROOT/"backend/src/FieldVisit.Application/Contracts.cs"
replace_once(
    p,
    'public sealed record UpdateLocationRequest(string LocationName, string? City, string? District, string? Address, string? PlusCode, string RowVersion);\npublic sealed record BatchPublishLocationsRequest',
    'public sealed record UpdateLocationRequest(string LocationName, string? City, string? District, string? Address, string? PlusCode, string RowVersion);\npublic sealed record PromoteLocationRequest(string RowVersion);\npublic sealed record BatchPublishLocationsRequest',
    "Contracts"
)

# MasterService
p = ROOT/"backend/src/FieldVisit.Application/MasterAndReportServices.cs"
replace_once(
    p,
'''        await uow.SaveChangesAsync(ct);
        return MapLocation(row);
    }

    public async Task<BatchPublishLocationsResult> BatchPublishAsync''',
'''        await uow.SaveChangesAsync(ct);
        return MapLocation(row);
    }

    public async Task<LocationDto> PromoteTemporaryLocationAsync(
        int id,
        PromoteLocationRequest request,
        CancellationToken ct)
    {
        var user = RequireAny("admin");
        var row = await masters.GetLocationAsync(id, true, ct)
            ?? throw new KeyNotFoundException("找不到地點。");

        if (user.OrganizationId.HasValue
            && row.OrganizationId.HasValue
            && row.OrganizationId != user.OrganizationId)
            throw new UnauthorizedAccessException("無權維護其他 Organization 地點。");

        EnsureRowVersion(row.RowVersion, request.RowVersion);
        V170LocationPromotionRules.EnsureCanPromote(row);

        row.IsTemporary = false;
        row.UpdatedAt = DateTime.UtcNow;

        await workflow.AddLocationHistoryAsync(new LocationApprovalHistory
        {
            LocationId = row.LocationId,
            Action = "PromotedToOfficial",
            ReviewedByUserId = user.UserId,
            Comments = "管理者將已核准臨時地點轉為正式地點",
            ActionAt = DateTime.UtcNow
        }, ct);

        await workflow.AddAuditAsync(
            Audit(user.UserId, "Location", id.ToString(), "LocationPromoteToOfficial",
                new { locationId = id, row.LocationName }),
            ct);

        await uow.SaveChangesAsync(ct);
        return MapLocation(row);
    }

    public async Task<BatchPublishLocationsResult> BatchPublishAsync''',
    "MasterService"
)

# MasterController
p = ROOT/"backend/src/FieldVisit.Api/Controllers/MasterController.cs"
replace_once(
    p,
'''    [HttpGet("projects")]
    public async Task<ActionResult<List<ProjectDto>>> Projects''',
'''    [HttpPost("locations/{locationId:int}/promote")]
    [Authorize(Roles = "admin")]
    public async Task<ActionResult<LocationDto>> PromoteLocation(
        int locationId,
        PromoteLocationRequest request,
        CancellationToken ct)
        => Ok(await master.PromoteTemporaryLocationAsync(locationId, request, ct));

    [HttpGet("projects")]
    public async Task<ActionResult<List<ProjectDto>>> Projects''',
    "MasterController"
)

# Project location admin contracts/interface/service
p = ROOT/"backend/src/FieldVisit.Application/V170ProjectLocationAdmin.cs"
text = p.read_text(encoding="utf-8")

for old,new in [
(
'''public sealed record V170SaveProjectLocationsRequest(
    IReadOnlyList<int> LocationIds);

public static class''',
'''public sealed record V170SaveProjectLocationsRequest(
    IReadOnlyList<int> LocationIds);

public sealed record V170ProjectLocationCountDto(
    int ProjectId,
    int Count);

public static class'''
),
(
'''    Task<List<ProjectLocation>> GetAssignmentsAsync(
        int projectId,
        CancellationToken ct);

    Task AddAssignmentAsync(''',
'''    Task<List<ProjectLocation>> GetAssignmentsAsync(
        int projectId,
        CancellationToken ct);

    Task<IReadOnlyList<V170ProjectLocationCountDto>> GetLocationCountsAsync(
        int organizationId,
        CancellationToken ct);

    Task AddAssignmentAsync('''
),
(
'''    public async Task<
        IReadOnlyList<V170ProjectLocationItemDto>>
        GetAsync(
            int projectId,
            CancellationToken ct)
    {''',
'''    public async Task<IReadOnlyList<V170ProjectLocationCountDto>>
        GetLocationCountsAsync(CancellationToken ct)
    {
        var user = RequireAdmin();
        return await repository.GetLocationCountsAsync(
            user.OrganizationId!.Value,
            ct);
    }

    public async Task<
        IReadOnlyList<V170ProjectLocationItemDto>>
        GetAsync(
            int projectId,
            CancellationToken ct)
    {'''
)
]:
    if new not in text:
        if old not in text:
            raise SystemExit("V170ProjectLocationAdmin marker not found")
        text = text.replace(old,new,1)

p.write_text(text, encoding="utf-8")
print("V170ProjectLocationAdmin: patched")

# Repository counts
p = ROOT/"backend/src/FieldVisit.Infrastructure/V170ProjectLocationAdminRepository.cs"
replace_once(
    p,
'''    public Task AddAssignmentAsync(
        ProjectLocation row,
        CancellationToken ct)
    {
        return db.ProjectLocations''',
'''    public async Task<IReadOnlyList<V170ProjectLocationCountDto>>
        GetLocationCountsAsync(
            int organizationId,
            CancellationToken ct)
    {
        return await db.Projects
            .AsNoTracking()
            .Where(x => x.OrganizationId == organizationId)
            .Select(x => new V170ProjectLocationCountDto(
                x.ProjectId,
                db.ProjectLocations
                    .AsNoTracking()
                    .Count(a => a.ProjectId == x.ProjectId && a.IsActive)))
            .ToListAsync(ct);
    }

    public Task AddAssignmentAsync(
        ProjectLocation row,
        CancellationToken ct)
    {
        return db.ProjectLocations''',
    "ProjectLocationRepository"
)

# Frontend type
p = ROOT/"frontend/src/types.ts"
replace_once(
    p,
'''export interface ProjectLocationCandidateResult{
  items:ProjectLocationAdminItem[];
  page:number;''',
'''export interface ProjectLocationCount{
  projectId:number;
  count:number;
}

export interface ProjectLocationCandidateResult{
  items:ProjectLocationAdminItem[];
  page:number;''',
    "Frontend types"
)

# AdminPage
p = ROOT/"frontend/src/pages/AdminPage.tsx"
text = p.read_text(encoding="utf-8")

old='Project,Team,VisitType}from"../types";'
new='Project,ProjectLocationCount,Team,VisitType}from"../types";'
if new not in text:
    if old not in text:
        raise SystemExit("AdminPage import marker not found")
    text=text.replace(old,new,1)

old=''' const deactivate=async(l:ManagedLocation)=>{if(!window.confirm(`確定停用地點「${l.locationName}」？歷史行程 Snapshot 不受影響。`))return;setBusy(true);try{await api(`/managed-locations/${l.locationId}`,{method:'DELETE'});setMsg('地點已停用。');await load()}catch(e){setMsg(e instanceof Error?e.message:'停用失敗')}finally{setBusy(false)}};
 const poll=async(id:string)=>{'''
new=''' const deactivate=async(l:ManagedLocation)=>{if(!window.confirm(`確定停用地點「${l.locationName}」？歷史行程 Snapshot 不受影響。`))return;setBusy(true);try{await api(`/managed-locations/${l.locationId}`,{method:'DELETE'});setMsg('地點已停用。');await load()}catch(e){setMsg(e instanceof Error?e.message:'停用失敗')}finally{setBusy(false)}};
 const promote=async(l:ManagedLocation)=>{if(!window.confirm(`確定將「${l.locationName}」轉為正式地點？\\n\\n轉換後可加入專案固定地點；既有歷史行程不會被修改。`))return;setBusy(true);try{await api(`/locations/${l.locationId}/promote`,{method:'POST',body:JSON.stringify({rowVersion:l.rowVersion})});setMsg(`地點「${l.locationName}」已轉為正式地點。`);await load()}catch(e){setMsg(e instanceof Error?e.message:'轉為正式地點失敗')}finally{setBusy(false)}};
 const poll=async(id:string)=>{'''
if new not in text:
    if old not in text:
        raise SystemExit("AdminPage promote marker not found")
    text=text.replace(old,new,1)

old='''<table><thead><tr><th></th><th>地點代碼</th><th>地點</th><th>小組</th><th>地址</th><th>解析</th><th>狀態</th><th>操作</th></tr></thead><tbody>{rows.map(l=><tr key={l.locationId}><td><input type="checkbox" checked={selected.includes(l.locationId)} onChange={e=>setSelected(x=>e.target.checked?[...x,l.locationId]:x.filter(id=>id!==l.locationId))}/></td><td>{l.locationCode}</td><td>{l.locationName}</td><td>{l.teamName||'全組織'}</td><td>{l.address||l.plusCode||'—'}</td><td>{l.geocodingStatus}</td><td>{l.isActive?'啟用':l.approvalStatus}</td><td><div className="actions"><button className="btn small secondary" onClick={()=>open(l)}>修改</button>{l.isActive&&<button className="btn small outline" disabled={busy} onClick={()=>void deactivate(l)}>停用</button>}</div></td></tr>)}</tbody></table>'''
new='''<table><thead><tr><th></th><th>地點代碼</th><th>地點</th><th>類型</th><th>小組</th><th>地址</th><th>解析</th><th>狀態</th><th>操作</th></tr></thead><tbody>{rows.map(l=>{const canPromote=l.isTemporary&&l.isActive&&l.approvalStatus==='Approved'&&l.geocodingStatus==='Completed';return <tr key={l.locationId}><td><input type="checkbox" checked={selected.includes(l.locationId)} onChange={e=>setSelected(x=>e.target.checked?[...x,l.locationId]:x.filter(id=>id!==l.locationId))}/></td><td>{l.locationCode}</td><td>{l.locationName}</td><td>{l.isTemporary?<span className="pill warn">臨時</span>:<span className="pill ok">正式</span>}</td><td>{l.teamName||'全組織'}</td><td>{l.address||l.plusCode||'—'}</td><td>{l.geocodingStatus}</td><td>{l.isActive?'啟用':l.approvalStatus}</td><td><div className="actions"><button className="btn small secondary" onClick={()=>open(l)}>修改</button>{canPromote&&<button className="btn small ok" disabled={busy} onClick={()=>void promote(l)}>轉正式</button>}{l.isActive&&<button className="btn small outline" disabled={busy} onClick={()=>void deactivate(l)}>停用</button>}</div></td></tr>})}</tbody></table>'''
if new not in text:
    if old not in text:
        raise SystemExit("AdminPage location table marker not found")
    text=text.replace(old,new,1)

old=''' const[projects,setProjects]=useState<Project[]>([]),[types,setTypes]=useState<VisitType[]>([]),[teams,setTeams]=useState<Team[]>([]),[edit,setEdit]=useState<Project|null>(null),[code,setCode]=useState(''),[name,setName]=useState(''),[teamId,setTeamId]=useState(''),[mode,setMode]=useState('List'),[start,setStart]=useState(todayTaipei()),[end,setEnd]=useState(''),[desc,setDesc]=useState('');
 const[typeEdit,setTypeEdit]=useState<VisitType|null>(null),[typeCode,setTypeCode]=useState(''),[typeName,setTypeName]=useState(''),[typeDesc,setTypeDesc]=useState(''),[sort,setSort]=useState('10');
 const load=()=>Promise.all([api<Project[]>('/projects'),api<VisitType[]>('/visit-types'),api<Team[]>('/teams')]).then(([p,v,t])=>{setProjects(p);setTypes(v);setTeams(t);if(!typeEdit)setSort(String(Math.max(0,...v.map(x=>x.sortOrder))+10))}).catch(e=>setMsg(e.message));useEffect(()=>{void load()},[]);'''
new=''' const[projects,setProjects]=useState<Project[]>([]),[types,setTypes]=useState<VisitType[]>([]),[teams,setTeams]=useState<Team[]>([]),[locationCounts,setLocationCounts]=useState<Record<number,number>>({}),[edit,setEdit]=useState<Project|null>(null),[code,setCode]=useState(''),[name,setName]=useState(''),[teamId,setTeamId]=useState(''),[mode,setMode]=useState('List'),[start,setStart]=useState(todayTaipei()),[end,setEnd]=useState(''),[desc,setDesc]=useState('');
 const[typeEdit,setTypeEdit]=useState<VisitType|null>(null),[typeCode,setTypeCode]=useState(''),[typeName,setTypeName]=useState(''),[typeDesc,setTypeDesc]=useState(''),[sort,setSort]=useState('10');
 const load=()=>Promise.all([api<Project[]>('/projects'),api<VisitType[]>('/visit-types'),api<Team[]>('/teams'),api<ProjectLocationCount[]>('/admin/projects/location-counts')]).then(([p,v,t,c])=>{setProjects(p);setTypes(v);setTeams(t);setLocationCounts(Object.fromEntries(c.map(x=>[x.projectId,x.count])));if(!typeEdit)setSort(String(Math.max(0,...v.map(x=>x.sortOrder))+10))}).catch(e=>setMsg(e.message));useEffect(()=>{void load()},[]);'''
if new not in text:
    if old not in text:
        raise SystemExit("AdminPage project load marker not found")
    text=text.replace(old,new,1)

old='''<div className="table-wrap"><table><thead><tr><th>代碼</th><th>名稱</th><th>地點方式</th><th>操作</th></tr></thead><tbody>{projects.map(p=><tr key={p.projectId}><td>{p.projectCode}</td><td>{p.projectName}{!p.isActive&&<span className="pill warn">停用</span>}</td><td>{p.locationMode==='List'?'專案清單優先':'臨時維護優先'}</td><td><div className="actions"><button className="btn small secondary" onClick={()=>open(p)}>修改</button>{p.isActive&&<button className="btn small outline" disabled={busy} onClick={()=>void deactivateProject(p)}>停用</button>}</div></td></tr>)}</tbody></table></div>'''
new='''<div className="table-wrap"><table><thead><tr><th>專案</th><th>歸屬小組</th><th>有效期間</th><th>地點規則</th><th>固定地點</th><th>狀態</th><th>操作</th></tr></thead><tbody>{projects.map(p=>{const teamName=p.teamId?teams.find(t=>t.teamId===p.teamId)?.teamName||`Team ${p.teamId}`:'全組織';const period=`${p.startDate||'不限'}～${p.endDate||'無期限'}`;return <tr key={p.projectId}><td><strong>{p.projectCode}</strong><div>{p.projectName}</div>{p.description&&<div className="sub">{p.description}</div>}</td><td>{teamName}</td><td>{period}</td><td>{p.locationMode==='List'?'專案清單優先':'臨時維護優先'}</td><td>{p.locationMode==='List'?`${locationCounts[p.projectId]??0} 筆`:'—'}</td><td>{p.isActive?<span className="pill ok">啟用</span>:<span className="pill warn">停用</span>}</td><td><div className="actions"><button className="btn small secondary" onClick={()=>open(p)}>修改</button>{p.isActive&&<button className="btn small outline" disabled={busy} onClick={()=>void deactivateProject(p)}>停用</button>}</div></td></tr>})}</tbody></table></div>'''
if new not in text:
    if old not in text:
        raise SystemExit("AdminPage project table marker not found")
    text=text.replace(old,new,1)

p.write_text(text, encoding="utf-8")
print("AdminPage: patched")
