#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / 'frontend/src/pages/TeamManagementPage.tsx'
text = path.read_text(encoding='utf-8')
old = '   {!selectedTeam?<div className="empty">請先選擇小組。</div>:<div className="table-wrap"><table><thead><tr><th>員編</th><th>姓名</th><th>角色</th><th>本小組成員</th><th>主要小組</th><th>目前小組範圍</th></tr></thead><tbody>{users.map(u=>{\n    const scope=u.teamScopes.find(s=>s.teamId===selectedTeam.teamId);\n    return <tr key={u.userId}><td>{u.employeeNo}</td><td>{u.displayName}</td><td>{u.roles.join("、")||"—"}</td><td><label className="check-row"><input type="checkbox" checked={!!scope} disabled={busy||(!selectedTeam.isActive&&!scope)} onChange={e=>void toggleMember(u,e.target.checked)}/>{scope?"已加入":"未加入"}</label></td><td>{scope?<label className="check-row"><input type="radio" name={`primary-${u.userId}`} checked={scope.isPrimary} disabled={busy} onChange={()=>void setPrimary(u)}/>{scope.isPrimary?"主要":"設為主要"}</label>:"—"}</td><td>{u.teamScopes.map(s=>`${s.teamName}${s.isPrimary?" ★":""}`).join("、")||"—"}</td></tr>\n   })}</tbody></table></div>}'
new = '   {!selectedTeam?<div className="empty">請先選擇小組。</div>:<>\n    <div className="sub" style={{marginBottom:10}}>一人可同時屬於多個小組；★ 代表主要小組。勾選「加入此小組」只會新增此小組，不會移除既有所屬小組。</div>\n    <div className="table-wrap"><table><thead><tr><th>員編</th><th>姓名</th><th>角色</th><th>{selectedTeam.teamCode} {selectedTeam.teamName}成員</th><th>是否主要小組</th><th>所屬小組</th></tr></thead><tbody>{users.map(u=>{\n    const scope=u.teamScopes.find(s=>s.teamId===selectedTeam.teamId);\n    return <tr key={u.userId}><td>{u.employeeNo}</td><td>{u.displayName}</td><td>{u.roles.join("、")||"—"}</td><td><label className="check-row"><input type="checkbox" checked={!!scope} disabled={busy||(!selectedTeam.isActive&&!scope)} onChange={e=>void toggleMember(u,e.target.checked)}/>{scope?"已加入此小組":"加入此小組"}</label></td><td>{scope?<label className="check-row"><input type="radio" name={`primary-${u.userId}`} checked={scope.isPrimary} disabled={busy} onChange={()=>void setPrimary(u)}/>{scope.isPrimary?"主要小組":"設為主要"}</label>:"—"}</td><td>{u.teamScopes.map(s=>`${s.teamName}${s.isPrimary?" ★":""}`).join("、")||"—"}</td></tr>\n   })}</tbody></table></div>\n   </>}'
if new in text:
    print('TeamManagementPage.tsx: already patched')
elif old not in text:
    raise SystemExit('TeamManagementPage.tsx: target block not found; stop to avoid patching wrong version')
else:
    path.write_text(text.replace(old, new, 1), encoding='utf-8')
    print('TeamManagementPage.tsx: patched')
print('Team membership UX fix completed.')