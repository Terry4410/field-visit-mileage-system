from pathlib import Path

def replace_once(text, old, new, label):
    if new in text:
        print(f"{label}: already patched")
        return text
    if old not in text:
        raise SystemExit(f"{label}: 找不到預期內容；停止，避免錯改。")
    print(f"{label}: patched")
    return text.replace(old, new, 1)

# 1) Frontend time formatter
p = Path("frontend/src/v160.ts")
text = p.read_text(encoding="utf-8")
line = 'export const timeRange=(start?:string|null,end?:string|null)=>{const s=(start||"").slice(0,5);const e=(end||"").slice(0,5);return s&&e?`${s}～${e}`:s?`${s}～—`:e?`—～${e}`:"—"};\n'
if "export const timeRange=" not in text:
    text += line
    p.write_text(text, encoding="utf-8")
    print("v160.ts: added timeRange")
else:
    print("v160.ts: timeRange already exists")

# 2) Unified query page
p = Path("frontend/src/pages/UnifiedQueryPage.tsx")
text = p.read_text(encoding="utf-8")
text = replace_once(
    text,
    'import{km,money,monthStart,previousMonthRange,qs,threeMonthStart,todayTaipei}from"../v160";',
    'import{km,money,monthStart,previousMonthRange,qs,threeMonthStart,timeRange,todayTaipei}from"../v160";',
    "UnifiedQueryPage import"
)
text = replace_once(
    text,
    '<th>日期</th><th>外訪員</th>',
    '<th>日期</th><th>時間</th><th>外訪員</th>',
    "UnifiedQueryPage table header"
)
text = replace_once(
    text,
    '<td>{r.visitDate}</td><td>{r.visitorName}</td>',
    '<td>{r.visitDate}</td><td>{timeRange(r.startTime,r.endTime)}</td><td>{r.visitorName}</td>',
    "UnifiedQueryPage table row"
)
text = replace_once(
    text,
    '{detail.visitDate}｜{detail.visitorName}｜',
    '{detail.visitDate}｜{timeRange(detail.startTime,detail.endTime)}｜{detail.visitorName}｜',
    "UnifiedQueryPage detail"
)
p.write_text(text, encoding="utf-8")

# 3) Backend reports
p = Path("backend/src/FieldVisit.Infrastructure/ReportDocumentService.cs")
text = p.read_text(encoding="utf-8")

text = replace_once(
    text,
    'var columns = new[] { 68f, 52f, 55f, 45f, 60f, 55f, 150f, 38f, 38f, 38f, 42f, 50f, 50f };',
    'var columns = new[] { 64f, 48f, 48f, 52f, 43f, 50f, 48f, 135f, 35f, 35f, 35f, 38f, 44f, 44f };',
    "PDF columns"
)
text = replace_once(
    text,
    'var headers = new[] { "TripNo", "日期", "外訪員", "小組", "專案", "拜訪形式", "拜訪路線", "自算", "系統", "核定", "費率", "補助金額", "狀態" };',
    'var headers = new[] { "TripNo", "日期", "時間", "外訪員", "小組", "專案", "拜訪形式", "拜訪路線", "自算", "系統", "核定", "費率", "補助金額", "狀態" };',
    "PDF headers"
)
text = replace_once(
    text,
    'r.TripNo, r.VisitDate.ToString("yyyy/MM/dd"), r.VisitorName, r.TeamName ?? "—", Truncate(r.ProjectNames, 12),',
    'r.TripNo, r.VisitDate.ToString("yyyy/MM/dd"), TimeRange(r.StartTime, r.EndTime), r.VisitorName, r.TeamName ?? "—", Truncate(r.ProjectNames, 12),',
    "PDF cells"
)

text = replace_once(
    text,
    'yield return new object?[] { "日期", "TripNo", "外訪員", "員編", "小組", "專案", "拜訪形式", "拜訪順序", "自算里程", "系統里程", "核定里程", "每公里補助", "補助金額", "狀態", "Snapshot版本", "更正狀態", "備註" };',
    'yield return new object?[] { "日期", "時間", "TripNo", "外訪員", "員編", "小組", "專案", "拜訪形式", "拜訪順序", "自算里程", "系統里程", "核定里程", "每公里補助", "補助金額", "狀態", "Snapshot版本", "更正狀態", "備註" };',
    "Excel summary headers"
)
text = replace_once(
    text,
    'foreach (var r in rows) yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), r.TripNo, r.VisitorName, r.EmployeeNo, r.TeamName, r.ProjectNames, r.VisitTypeNames, r.Route, r.ClaimedDistanceKm, r.SystemDistanceKm, r.ApprovedDistanceKm, r.RatePerKmSnapshot, r.SubsidyAmount, r.StatusName, r.SnapshotVersion, r.CorrectionStatus, r.Notes };',
    'foreach (var r in rows) yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), TimeRange(r.StartTime, r.EndTime), r.TripNo, r.VisitorName, r.EmployeeNo, r.TeamName, r.ProjectNames, r.VisitTypeNames, r.Route, r.ClaimedDistanceKm, r.SystemDistanceKm, r.ApprovedDistanceKm, r.RatePerKmSnapshot, r.SubsidyAmount, r.StatusName, r.SnapshotVersion, r.CorrectionStatus, r.Notes };',
    "Excel summary rows"
)
text = replace_once(
    text,
    'yield return new object?[] { "日期", "TripNo", "外訪員", "小組", "順序", "地點代碼", "地點名稱", "地址", "專案代碼", "專案名稱", "拜訪形式代碼", "拜訪形式", "行程目的", "備註" };',
    'yield return new object?[] { "日期", "時間", "TripNo", "外訪員", "小組", "順序", "地點代碼", "地點名稱", "地址", "專案代碼", "專案名稱", "拜訪形式代碼", "拜訪形式", "行程目的", "備註" };',
    "Excel stop headers"
)
text = replace_once(
    text,
    'yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), r.TripNo, r.VisitorName, r.TeamName, s.StopSequence, s.LocationCode, s.LocationName, s.Address, s.ProjectCode, s.ProjectName, s.VisitTypeCode, s.VisitTypeName, s.VisitPurpose, s.Notes };',
    'yield return new object?[] { r.VisitDate.ToString("yyyy-MM-dd"), TimeRange(r.StartTime, r.EndTime), r.TripNo, r.VisitorName, r.TeamName, s.StopSequence, s.LocationCode, s.LocationName, s.Address, s.ProjectCode, s.ProjectName, s.VisitTypeCode, s.VisitTypeName, s.VisitPurpose, s.Notes };',
    "Excel stop rows"
)

helper_old = '    private static string Km(decimal? value) => value.HasValue ? value.Value.ToString("0.##") : "N/A";'
helper_new = '''    private static string TimeRange(TimeOnly? start, TimeOnly? end)
    {
        var s = start?.ToString("HH:mm");
        var e = end?.ToString("HH:mm");
        if (s is not null && e is not null) return $"{s}～{e}";
        if (s is not null) return $"{s}～—";
        if (e is not null) return $"—～{e}";
        return "—";
    }

    private static string Km(decimal? value) => value.HasValue ? value.Value.ToString("0.##") : "N/A";'''
text = replace_once(text, helper_old, helper_new, "Report TimeRange helper")
p.write_text(text, encoding="utf-8")

print("All requested patches applied successfully.")
