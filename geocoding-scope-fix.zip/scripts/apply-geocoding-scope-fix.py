#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / "backend/src/FieldVisit.Infrastructure/BackgroundJobService.cs"
text = p.read_text(encoding="utf-8")

def replace_once(old, new, label):
    global text
    if new in text:
        print(f"{label}: already patched")
        return
    if old not in text:
        raise SystemExit(f"{label}: marker not found; stop to avoid patching wrong version")
    text = text.replace(old, new, 1)
    print(f"{label}: patched")

replace_once(
'''        var normalized = request with { Mode = mode };
        var row = NewJob("Geocoding", mode, user, JsonSerializer.Serialize(normalized, JsonOptions));
        await db.BackgroundJobs.AddAsync(row, ct);
        AddAudit(user.UserId, "BackgroundJob", row.BackgroundJobId.ToString(), "GeocodingJobEnqueued", new { Mode = mode, Count = request.LocationIds?.Count ?? 0, request.StartDate, request.EndDate, user.TeamIds });''',
'''        var normalized = request with { Mode = mode };
        var row = NewJob("Geocoding", mode, user, JsonSerializer.Serialize(normalized, JsonOptions));

        // Geocoding scope must match the formal-location access rules:
        // - admin: organization-wide (no TeamId restriction)
        // - leader: authorized teams + organization-wide locations (TeamId = null)
        if (HasRole(user, "admin"))
            row.TeamScopeJson = JsonSerializer.Serialize(Array.Empty<int>(), JsonOptions);

        await db.BackgroundJobs.AddAsync(row, ct);
        AddAudit(
            user.UserId,
            "BackgroundJob",
            row.BackgroundJobId.ToString(),
            "GeocodingJobEnqueued",
            new
            {
                Mode = mode,
                Count = request.LocationIds?.Count ?? 0,
                request.StartDate,
                request.EndDate,
                Scope = HasRole(user, "admin") ? "Organization" : "TeamsAndGlobal",
                TeamIds = HasRole(user, "admin") ? Array.Empty<int>() : user.TeamIds
            });''',
"admin geocoding scope"
)

replace_once(
'''        if (teamIds.Count > 0) q = q.Where(x => x.TeamId.HasValue && teamIds.Contains(x.TeamId.Value));''',
'''        if (teamIds.Count > 0)
            q = q.Where(
                x => x.TeamId == null
                     || (x.TeamId.HasValue
                         && teamIds.Contains(x.TeamId.Value)));''',
"leader/global geocoding scope"
)

p.write_text(text, encoding="utf-8")
print("Geocoding background-job scope fix completed.")
