#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / "frontend/src/pages/VisitorPage.tsx"
text = p.read_text(encoding="utf-8")

def replace_once(old, new, label):
    global text
    if new in text:
        print(f"{label}: already patched")
        return
    if old not in text:
        raise SystemExit(f"{label}: marker not found")
    text = text.replace(old, new, 1)
    print(f"{label}: patched")

replace_once(
    '        setProjectId("");\n        setVisitTypeId(String(v[0]?.visitTypeId||""));',
    '        setProjectId("");\n        setVisitTypeId("");',
    "initial visit type"
)

replace_once(
    '    setProjectId("");\n    setVisitTypeId(String(visitTypes[0]?.visitTypeId||""));',
    '    setProjectId("");\n    setVisitTypeId("");',
    "reset visit type"
)

replace_once(
    '    setProjectId(stop.projectId?String(stop.projectId):"");\n    setVisitTypeId(String(stop.visitTypeId||visitTypes[0]?.visitTypeId||""));',
    '    setProjectId(stop.projectId?String(stop.projectId):"");\n    setVisitTypeId(stop.visitTypeId?String(stop.visitTypeId):"");',
    "edit visit type"
)

replace_once(
    '    const selectedProjectId=projectId?Number(projectId):undefined;\n    const visitType=selectedProjectId?visitTypes.find(x=>x.visitTypeId===Number(visitTypeId)):undefined;\n    if(selectedProjectId&&!visitType)return setMsg("有選擇專案時，請選擇拜訪形式。");',
    '    const selectedProjectId=projectId?Number(projectId):undefined;\n    const visitType=visitTypeId\n      ?visitTypes.find(x=>x.visitTypeId===Number(visitTypeId))\n      :undefined;\n    if(visitTypeId&&!visitType)\n      return setMsg("請重新選擇有效的拜訪形式。");',
    "save visit type independently"
)

replace_once(
    '''        {projectId&&<div className="field">
          <label>拜訪形式</label>
          <select value={visitTypeId} onChange={e=>setVisitTypeId(e.target.value)}>
            {visitTypes.map(v=><option key={v.visitTypeId} value={v.visitTypeId}>{v.visitTypeName}</option>)}
          </select>
        </div>}''',
    '''        <div className="field">
          <label>拜訪形式 <span className="muted">選填</span></label>
          <select value={visitTypeId} onChange={e=>setVisitTypeId(e.target.value)}>
            <option value="">未指定</option>
            {visitTypes.map(v=><option key={v.visitTypeId} value={v.visitTypeId}>{v.visitTypeName}</option>)}
          </select>
        </div>''',
    "always-visible visit type selector"
)

p.write_text(text, encoding="utf-8")
print("VisitorPage visit type independence fix completed.")
