#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / "backend/src/FieldVisit.Application/TripService.cs"
text = p.read_text(encoding="utf-8")

old = '''        if (trip.StartTime is null || trip.EndTime is null)
            throw new InvalidOperationException("送出前必須填寫起訖時間。");

        var calc = await mileage.GetByTripAsync(trip.VisitTripId, true, ct);'''

new = '''        if (trip.StartTime is null || trip.EndTime is null)
            throw new InvalidOperationException("送出前必須填寫起訖時間。");

        // Defense in depth:
        // A draft can remain open while an administrator disables a VisitType.
        // Normal UI editing revalidates the Stop through BuildStopsAsync, but a
        // caller could otherwise invoke /submit directly without re-saving the
        // draft. Re-check each referenced VisitType here before status changes.
        foreach (var stop in trip.Stops.Where(x => x.VisitTypeId.HasValue))
        {
            var visitType =
                await masters.GetVisitTypeAsync(
                    stop.VisitTypeId!.Value,
                    false,
                    ct)
                ?? throw new KeyNotFoundException(
                    $"找不到拜訪形式 {stop.VisitTypeId.Value}。");

            if (!visitType.IsActive)
                throw new InvalidOperationException(
                    $"拜訪形式「{visitType.VisitTypeName}」已停用，請重新選擇拜訪形式。");
        }

        var calc = await mileage.GetByTripAsync(trip.VisitTripId, true, ct);'''

if new in text:
    print("TripService submit VisitType hardening: already patched")
elif old not in text:
    raise SystemExit("TripService marker not found; stop to avoid patching wrong version")
else:
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("TripService submit VisitType hardening: patched")
