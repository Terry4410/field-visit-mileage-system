#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "backend/src/FieldVisit.Application/TripService.cs"

text = path.read_text(encoding="utf-8")

old = '''        EnsureRowVersion(trip.RowVersion, rowVersion);

        trip.Status = TripStatuses.Cancelled;
        trip.UpdatedAt = DateTime.UtcNow;
        trip.UpdatedByUserId = user.UserId;

        await AddHistoryAsync(trip, TripStatuses.Draft, TripStatuses.Cancelled, "DeleteDraft", user.UserId, "使用者刪除草稿", ct);
        await AuditAsync(user.UserId, "Trip", trip.VisitTripId.ToString(), "TripDeleteDraft", new { Status = TripStatuses.Draft }, new { Status = TripStatuses.Cancelled }, ct);
        await uow.SaveChangesAsync(ct);
'''

new = '''        EnsureRowVersion(trip.RowVersion, rowVersion);

        var pendingTemporaryLocationIds =
            V170TemporaryLocationCleanupRules
                .GetPendingTemporaryLocationIds(trip);

        trip.Status = TripStatuses.Cancelled;
        trip.UpdatedAt = DateTime.UtcNow;
        trip.UpdatedByUserId = user.UserId;

        await AddHistoryAsync(trip, TripStatuses.Draft, TripStatuses.Cancelled, "DeleteDraft", user.UserId, "使用者刪除草稿", ct);
        await AuditAsync(user.UserId, "Trip", trip.VisitTripId.ToString(), "TripDeleteDraft", new { Status = TripStatuses.Draft }, new { Status = TripStatuses.Cancelled }, ct);

        // Persist the cancellation first. The repository cleanup query must see
        // this trip as Cancelled before deciding whether the temporary location
        // is still referenced by any non-cancelled trip.
        await uow.SaveChangesAsync(ct);

        if (pendingTemporaryLocationIds.Count > 0)
        {
            await masters.AbandonUnusedTemporaryLocationsAsync(
                pendingTemporaryLocationIds,
                ct);

            await uow.SaveChangesAsync(ct);
        }
'''

if new in text:
    print("TripService.DeleteDraftAsync already patched.")
elif old not in text:
    raise SystemExit(
        "DeleteDraftAsync marker not found. Stop to avoid patching the wrong version."
    )
else:
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("TripService.DeleteDraftAsync patched successfully.")
