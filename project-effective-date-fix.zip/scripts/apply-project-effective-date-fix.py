#!/usr/bin/env python3
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

# Frontend
visitor=ROOT/"frontend/src/pages/VisitorPage.tsx"
text=visitor.read_text(encoding="utf-8")

old_import='import {validateTripMileageForSubmit} from "../trip-submit-rules";'
new_import='import {validateTripMileageForSubmit} from "../trip-submit-rules";\nimport {isProjectAvailableOn} from "../project-date-rules";'

if new_import not in text:
    if old_import not in text:
        raise SystemExit("VisitorPage import marker not found.")
    text=text.replace(old_import,new_import,1)

old_selected = """  const selectedProject=projects.find(x=>x.projectId===Number(projectId));

  // Only list-mode projects restrict Smart Picker to ProjectLocations.
"""
new_selected = """  const availableProjects=useMemo(
    ()=>projects.filter(p=>isProjectAvailableOn(p,date)),
    [projects,date]
  );

  const selectedProject=projects.find(x=>x.projectId===Number(projectId));

  useEffect(()=>{
    if(!projectId)return;
    if(availableProjects.some(
      p=>p.projectId===Number(projectId)
    ))return;

    setProjectId("");
    setSelectedExistingLocation(null);
    setLocationMethod("existing");
  },[availableProjects,projectId]);

  // Only list-mode projects restrict Smart Picker to ProjectLocations.
"""

if new_selected not in text:
    if old_selected not in text:
        raise SystemExit("VisitorPage selectedProject marker not found.")
    text=text.replace(old_selected,new_selected,1)

old_map='{projects.map(p=><option key={p.projectId} value={p.projectId}>{p.projectName}</option>)}'
new_map='{availableProjects.map(p=><option key={p.projectId} value={p.projectId}>{p.projectName}</option>)}'

if new_map not in text:
    if old_map not in text:
        raise SystemExit("VisitorPage project dropdown marker not found.")
    text=text.replace(old_map,new_map,1)

visitor.write_text(text,encoding="utf-8")
print("VisitorPage project-date filtering patched.")

# Backend
trip=ROOT/"backend/src/FieldVisit.Application/TripService.cs"
text=trip.read_text(encoding="utf-8")

old_backend = '                if (!project.IsActive) throw new InvalidOperationException($"專案「{project.ProjectName}」已停用。");\n                if (user.OrganizationId.HasValue && project.OrganizationId != user.OrganizationId)'
new_backend = '                V170ProjectDateRules.EnsureAvailableOn(\n                    project,\n                    trip.VisitDate);\n\n                if (user.OrganizationId.HasValue && project.OrganizationId != user.OrganizationId)'

if new_backend not in text:
    if old_backend not in text:
        raise SystemExit("TripService project validation marker not found.")
    text=text.replace(old_backend,new_backend,1)

trip.write_text(text,encoding="utf-8")
print("TripService project-date validation patched.")