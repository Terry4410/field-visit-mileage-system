from pathlib import Path

path = Path("backend/src/FieldVisit.Infrastructure/V160FinalRepository.cs")
if not path.exists():
    raise SystemExit(f"找不到 {path}；請從 repository root 執行。")

text = path.read_text(encoding="utf-8")

marker = '''    public async Task<IReadOnlyList<UserOptionDto>> GetScopedVisitorsAsync(CurrentUserDto user, CancellationToken ct)
    {
        var q = db.Users.AsNoTracking().Where(x => x.IsActive);
'''

insertion = '''    public async Task<IReadOnlyList<UserOptionDto>> GetScopedVisitorsAsync(CurrentUserDto user, CancellationToken ct)
    {
        var q = db.Users.AsNoTracking().Where(x => x.IsActive);

        // "query/visitors" is a Visitor selector, not a generic user selector.
        // v1.7 identity-enabled users use effective-dated UserRoleAssignments as
        // the role source of truth. Legacy users without an identity profile
        // keep the UserRoles compatibility fallback.
        var today = BusinessTime.Today;

        var currentVisitorUserIds =
            from assignment in db.UserRoleAssignments.AsNoTracking()
            join role in db.Roles.AsNoTracking()
                on assignment.RoleId equals role.RoleId
            where
                assignment.EffectiveFrom <= today
                && (!assignment.EffectiveTo.HasValue
                    || assignment.EffectiveTo >= today)
                && role.IsActive
                && role.RoleCode.ToUpper() == "VISITOR"
            select assignment.UserId;

        var legacyVisitorUserIds =
            from userRole in db.UserRoles.AsNoTracking()
            join role in db.Roles.AsNoTracking()
                on userRole.RoleId equals role.RoleId
            where
                role.IsActive
                && role.RoleCode.ToUpper() == "VISITOR"
                && !db.UserIdentityProfiles.Any(
                    profile => profile.UserId == userRole.UserId)
            select userRole.UserId;

        q = q.Where(
            x =>
                currentVisitorUserIds.Contains(x.UserId)
                || legacyVisitorUserIds.Contains(x.UserId));
'''

if insertion in text:
    print("Visitor role filter already applied.")
elif marker in text:
    text = text.replace(marker, insertion, 1)
    path.write_text(text, encoding="utf-8")
    print("Patched GetScopedVisitorsAsync visitor-role filter.")
else:
    raise SystemExit("找不到預期的 GetScopedVisitorsAsync 區塊；停止，避免錯改。")
