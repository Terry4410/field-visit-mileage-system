from pathlib import Path

path = Path("backend/src/FieldVisit.Application/TripService.cs")
if not path.exists():
    raise SystemExit(f"找不到 {path}；請從 repository root 執行。")

text = path.read_text(encoding="utf-8")

old_ctor = '''public sealed class TripService(
    ICurrentUserService current,
    IUserRepository users,
    ITripRepository trips,
    IMasterRepository masters,
    IMileageRepository mileage,
    IWorkflowRepository workflow,
    IUnitOfWork uow)'''

new_ctor = '''public sealed class TripService(
    ICurrentUserService current,
    IUserRepository users,
    ITripRepository trips,
    IMasterRepository masters,
    IMileageRepository mileage,
    IWorkflowRepository workflow,
    IV170AccessControl access,
    IUnitOfWork uow)'''

old_scope = '''        if (HasRole(user, "visitor") && trip.UserId != user.UserId)
            throw new UnauthorizedAccessException("無權查看其他外訪員行程。");
        if (HasRole(user, "leader") && (!trip.TeamId.HasValue || !user.TeamIds.Contains(trip.TeamId.Value)))
            throw new UnauthorizedAccessException("無權查看未授權小組行程。");
        if ((HasRole(user, "admin") || HasRole(user, "supervisor")) &&
            user.OrganizationId.HasValue && trip.OrganizationId != user.OrganizationId.Value)
            throw new UnauthorizedAccessException("無權查看其他 Organization 行程。");
        return await MapAsync(trip, ct);'''

new_scope = '''        if (HasRole(user, "visitor") && trip.UserId != user.UserId)
            throw new UnauthorizedAccessException("無權查看其他外訪員行程。");

        if (HasRole(user, "leader") && (!trip.TeamId.HasValue || !user.TeamIds.Contains(trip.TeamId.Value)))
            throw new UnauthorizedAccessException("無權查看未授權小組行程。");

        if (HasRole(user, "admin") &&
            user.OrganizationId.HasValue &&
            trip.OrganizationId != user.OrganizationId.Value)
        {
            throw new UnauthorizedAccessException("無權查看其他 Organization 行程。");
        }

        /*
         * Security:
         * Query/export already resolve the v1.7 Supervisor Data Scope.
         * Direct GET /trips/{id} must apply the same scope so a caller
         * cannot bypass the query list by guessing a VisitTripId.
         *
         * Admin+Supervisor keeps Admin semantics. A read-only external
         * Supervisor must pass Organization + Data Scope authorization.
         */
        if (HasRole(user, "supervisor") && !HasRole(user, "admin"))
        {
            var readScope =
                await access.ResolveReadScopeAsync(
                    user,
                    ct);

            if (!V170TripAccessRules.CanSupervisorReadTrip(
                    user,
                    trip.OrganizationId,
                    trip.TeamId,
                    readScope))
            {
                throw new UnauthorizedAccessException(
                    "無權查看未授權範圍的行程。");
            }
        }

        return await MapAsync(trip, ct);'''

if new_ctor in text:
    print("Constructor already patched.")
elif old_ctor in text:
    text = text.replace(old_ctor, new_ctor, 1)
    print("Patched TripService constructor.")
else:
    raise SystemExit("找不到預期的 TripService constructor；停止，避免錯改。")

if new_scope in text:
    print("GetDtoAsync scope already patched.")
elif old_scope in text:
    text = text.replace(old_scope, new_scope, 1)
    print("Patched GetDtoAsync Supervisor scope.")
else:
    raise SystemExit("找不到預期的 GetDtoAsync authorization block；停止，避免錯改。")

path.write_text(text, encoding="utf-8")
print("TripService.cs updated successfully.")
